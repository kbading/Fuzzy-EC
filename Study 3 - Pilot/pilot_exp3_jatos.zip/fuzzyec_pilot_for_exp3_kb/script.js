// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "fuzzyEC_pilot_for_exp3_KB",
    "description": "",
    "repository": "",
    "contributors": "Karoline Bading & Jérémy Béna\nMarius Barth\nKlaus Rothermund\n"
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "image",
          "src": "${ this.files[\"UT_WBMW_Rot_RGB_01.jpg\"] }",
          "name": ""
        },
        {
          "type": "text",
          "title": "\u003Ccenter\u003EConsent form to take part in the study entitled “impressions of words and faces” conducted online on Prolific\u003C\u002Fcenter\u003E",
          "content": "\u003Cp\u003EDear participant,\u003C\u002Fp\u003E\n\n\u003Cp style=\"text-align: justify;\"\u003EWe are researchers from the University of Tübingen (Germany) and from the Aix-Marseille Université (France). We are conducting a research study to examine how people judge words and faces. Participation in this study will involve completing a survey. Your involvement will require about 14 minutes. You will receive £ 2.10 (~ $ US 2.67) for participating.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EThere are no known or anticipated risks to you for participating. Although this study will not benefit you personally, we hope that our results will add to the knowledge about psychology and the judgment of words and faces in particular.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EThe researcher will not know your name, and no identifying information will be connected to your survey answers in any way. The survey is therefore anonymous.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EYour responses will be numbered and stored on a password-protected computer hard drive. The information you provide will be kept until publication. A data file containing your anonymous responses (without your Prolific ID) will be stored in a secure online archive (i.e., the Open Science Framework). This data file will be available to other researchers without time limit. \u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EParticipation in this study is completely voluntary. You are free to decline to participate, to end participation at any time for any reason, or to refuse to answer any individual question without penalty or loss of compensation.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EIf you want a copy of the consent form, click on the \"Download consent form\" button below (it will open a new tab in your browser; then go back to the experiment tab):\u003C\u002Fp\u003E\n\n\u003Ccenter\u003E\n\u003Cbutton type=\"submit\" onclick=\"window.open('${ 'static\u002Fconsent_form_online_pt.pdf'}')\"\u003EDownload consent form\u003C\u002Fbutton\u003E\n\u003C\u002Fcenter\u003E\n\n\u003Cp style=\"text-align: justify;\"\u003EDo you understand this consent form, agree with it, and want to participate in the study?\u003C\u002Fp\u003E"
        },
        {
          "required": true,
          "type": "html",
          "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"consent_yes\" name=\"consent\" value=\"1\" onclick=\"document.getElementById('end').click()\" required\u003E\r\n  \u003Clabel for=\"consent_yes\"\u003EYes, I understand, I agree, and I want to participate\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"consent_no\" name=\"consent\" value=\"0\" onclick=\"document.getElementById('end').click()\"\u003E\r\n  \u003Clabel for=\"consent_no\"\u003ENo, I do not want to participate\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003ENext!\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Ccenter\u003E",
          "name": ""
        },
        {
          "required": true,
          "type": "html",
          "content": "\u003Cp style=\"text-align: justify;\"\u003E\u003Cb\u003EInvestigators:\u003C\u002Fb\u003E\u003C\u002Fp\u003E\r\n\r\n\u003Cp\u003EDr. Karoline Bading, University of Tübingen \r\n\u003Cbr\u003E\u003Ci\u003ESchleichstraße 4, 72076 Tübingen, Germany\u003C\u002Fi\u003E\r\n\u003Cbr\u003E karoline.bading@uni-tuebingen.de\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cp\u003EDr. Jérémy Béna, Aix-Marseille Université\r\n\u003Cbr\u003E jeremy.bena@univ-amu.fr\u003C\u002Fp\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "Bandeau+new+logo+2019.jpg": "embedded\u002F5ffb7db9f15ad3b748ba63804367e87b2d52bf35af7d1cc696d84ef88aad1724.jpg",
        "Bildmarke_black_8cm.jpg": "embedded\u002F8d8205d13605ad5501ddcda7ec381eee3d98b9baf404875950775025a8c6f1bc.jpg",
        "UT_WBMW_Rot_RGB_01.jpg": "embedded\u002F237c6b7a2e0665a1903f1ad93455a1907ccf40781272b4e315bfb8eed7a5047c.jpg"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
// retrieve prolific pic
if (typeof jatos !== "undefined") {
   this.data.prolific_pid = jatos.urlQueryParameters.PROLIFIC_PID;
}

var trait = [//old_positive
  'dignified','considerate','wise','experienced','nurturing',
  'humble','realistic','selfless','calm','reasonable','patient',
  //young_positive
  'energetic','fast','strong','flexible','open-minded','spontaneous','easy-going','optimistic','lively','ambitious',
  //old_negative
  'slow','weak','feeble','frail','forgetful','confused','stubborn','demented','rigid','pessimistic',
  //young_negative
  'inexperienced','careless','ignorant','selfish','self-absorbed','arrogant','naive','unrealistic','inconsiderate','spoilt','impulsive'
  ]

var face = [
  '006_m_f_n_a','007_m_m_n_a','011_m_f_n_a','014_m_m_n_a','019_m_f_n_a',
  '026_m_m_n_a','029_m_f_n_a','032_m_m_n_a','035_m_f_n_a','038_m_m_n_a',
  '043_m_f_n_a','045_m_m_n_a','050_m_f_n_a','051_m_m_n_a','052_m_f_n_a',
  '056_m_m_n_a','058_m_m_n_a','061_m_f_n_a','064_m_f_n_a','068_m_m_n_a',
  '070_m_m_n_a','073_m_f_n_a','077_m_m_n_a','080_m_f_n_a','082_m_m_n_a',
  '084_m_f_n_a','087_m_m_n_a','092_m_m_n_a','093_m_f_n_a','094_m_m_n_a',
  '097_m_f_n_a','103_m_f_n_a','104_m_m_n_a','108_m_m_n_a','111_m_f_n_a',
  '113_m_f_n_a','116_m_m_n_a','117_m_f_n_a','122_m_f_n_a','126_m_m_n_a',
  '128_m_f_n_a','136_m_m_n_a','138_m_f_n_a','139_m_f_n_a','142_m_m_n_a',
  '149_m_m_n_a','155_m_m_n_a','156_m_f_n_a','157_m_f_n_a','159_m_m_n_a',
  '165_m_m_n_a','168_m_f_n_a','169_m_m_n_a','178_m_m_n_a','179_m_m_n_a',
  '180_m_f_n_a'
  ]

var valence = [
  //old_pos
  'pos','pos','pos','pos','pos','pos','pos','pos','pos','pos','pos',
  //young_pos
  'pos','pos','pos','pos','pos','pos','pos','pos','pos','pos',
  //old_neg
  'neg','neg','neg','neg','neg','neg','neg','neg','neg','neg',
  //young_neg
  'neg','neg','neg','neg','neg','neg','neg','neg','neg','neg','neg'
  ]

var age = [
  //old_pos
  'older','older','older','older','older','older','older','older','older','older','older', 
  //young_pos
  'younger','younger','younger','younger','younger','younger','younger','younger','younger','younger',
  //old_neg
  'older','older','older','older','older','older','older','older','older','older',
  //young_neg
  'younger','younger','younger','younger','younger','younger','younger','younger','younger','younger','younger'
  ]


var age_positions = ['younger_left','older_left']
var valence_positions = ['pos_left','neg_left']
var arousal_positions = ['arousing_left','non-arousing_left']

var age_position = this.random.shuffle(age_positions)
var valence_position = this.random.shuffle(valence_positions)
var arousal_position = this.random.shuffle(arousal_positions)

console.log(age_positions)
console.log(valence_positions)
console.log(arousal_positions)

console.log(age_position)
console.log(valence_position)
console.log(arousal_position)

var triallist = [];

//adjectives
for (var i=0 ; i < 42; i++) {
  triallist[i] = new Object();

  triallist[i].trait = trait[i]
  triallist[i].trait_valence = valence[i];
  triallist[i].age_group = age[i];
  if(age_position[0]=='younger_left'){
    triallist[i].oy_left = 'younger'
    triallist[i].oy_right = 'older'
  }
  if(age_position[0]=='older_left'){
    triallist[i].oy_left = 'older'
    triallist[i].oy_right = 'younger'
  }

  if(valence_position[0]=='pos_left'){
    triallist[i].pn_left = 'positive'
    triallist[i].pn_right = 'negative'
  }
  if(valence_position[0]=='neg_left'){
    triallist[i].pn_left = 'negative'
    triallist[i].pn_right = 'positive'
  }

  if(arousal_position[0]=='arousing_left'){
    triallist[i].ar_left = 'very emotionally intense'
    triallist[i].ar_right = 'not emotionally intense at all'
  }
  if(arousal_position[0]=='non-arousing_left'){
    triallist[i].ar_left = 'not emotionally intense at all'
    triallist[i].ar_right = 'very emotionally intense'
  }

  
};

triallist_traits = triallist.slice(0,42)

var triallist = [];

if(typeof(jatos) != 'undefined'){
 //jatos.studySessionData.triallist = triallist;
 jatos.studySessionData.triallist_traits = triallist_traits;
} else {  
  this.parent.parameters.triallist_traits = triallist_traits;
}

console.log(triallist)

//faces
for (var i=0 ; i < 56; i++) {
  triallist[i] = new Object();

  triallist[i].face = face[i]
  if(age_position[0]=='younger_left'){
    triallist[i].oy_left = 'young'
    triallist[i].oy_right = 'old'
  }
  if(age_position[0]=='older_left'){
    triallist[i].oy_left = 'old'
    triallist[i].oy_right = 'young'
  }

  if(valence_position[0]=='pos_left'){
    triallist[i].pn_left = 'likeable'
    triallist[i].pn_right = 'unlikeable'
  }
  if(valence_position[0]=='neg_left'){
    triallist[i].pn_left = 'unlikeable'
    triallist[i].pn_right = 'likeable'
  }

  if(arousal_position[0]=='arousing_left'){
    triallist[i].ar_left = 'very emotionally intense'
    triallist[i].ar_right = 'not emotionally intense at all'
  }
  if(arousal_position[0]=='non-arousing_left'){
    triallist[i].ar_left = 'not emotionally intense at all'
    triallist[i].ar_right = 'very emotionally intense'
  }

  
};

triallist_faces = triallist.slice(0,56)

if(typeof(jatos) != 'undefined'){
 //jatos.studySessionData.triallist = triallist;
 jatos.studySessionData.triallist_faces = triallist_faces;
} else {  
  this.parent.parameters.triallist_faces = triallist_faces;
}

console.log(triallist)



}
      },
      "title": "consent",
      "width": "l"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 771.4,
          "height": 101.25,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "As you do not wish to participate in this study, please press the Esc key \nand return your submission on Prolific by selecting the 'Stop without completing' button.\n\nThank you for your comprehension.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "20",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "if_consent_no",
      "tardy": true,
      "skip": "${this.state.consent!=0}"
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "full_screen",
      "plugins": [
        {
          "type": "fullscreen",
          "message": "",
          "hint": "",
          "path": "lab.plugins.Fullscreen"
        }
      ],
      "content": [
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "if_consent_yes",
          "tardy": true,
          "skip": "${this.state.consent!= 1}",
          "content": [
            {
              "type": "lab.html.Page",
              "items": [
                {
                  "type": "text",
                  "title": "Before you start...",
                  "content": "\u003Cp\u003EBefore you start, please switch off phone\u002Fe-mail\u002Fmusic so you can focus on this study.\u003C\u002Fp\u003E\n\n\u003Cp\u003EAlso, make sure you are using a computer  to take part in this study.\u003C\u002Fp\u003E\n\n\u003Cp\u003EThank you!\u003C\u002Fp\u003E"
                },
                {
                  "required": true,
                  "type": "html",
                  "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n  \u003Cform\u003E\r\n\u003Cdiv id=\"weiterdiv\"\u003E\u003Cbutton id=\"end\"\u003EStart!\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fform\u003E\r\n\u003C\u002Fcenter\u003E",
                  "name": ""
                }
              ],
              "scrollTop": true,
              "submitButtonText": "Los geht's!",
              "submitButtonPosition": "hidden",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "before_you_start",
              "width": "l"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 782.68,
                  "height": 232.33,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Thank you very much for your participation!\n\nYour voluntary participation makes an important contribution to a developing\nbody of knowledge in psychological science.\n\nWithout volunteer participants like you, the research we are doing would not be possible \nand we want to thank you for this contribution.\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "welcome_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "welcome"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 622.55,
                  "height": 179.9,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The study consists of two tasks and will take about 14 minutes.\n\nPlease read the following instructions attentively and perform all tasks \ncarefully and with due focus.\n\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "general_info_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "general_info"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 781.75,
                  "height": 363.41,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "In the first task, you will be presented with a number of\nadjectives that describe human traits and characteristics.\n\nFor each adjective, you will be presented with three questions about your \nimpression of the trait\u002Fcharacteristic described by it.\n\nThere are no right or wrong answers to these questions, so please rely on your personal \nimpression and try to respond as spontaneously as possible.\n\nAfter answering all three questions, please scroll down to the bottom of the page\nand click on the \"Continue\" button to proceed to the next adjective.\n\nPress the spacebar to start the task.\n",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "instructions_1"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw-shuffle",
                "n": ""
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData.triallist_traits;
} else {
  this.options.templateParameters = this.parent.parameters.triallist_traits;
}
}
              },
              "title": "adjective_rating_loop",
              "indexParameter": "count_adjective_ratings",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "sequence_rating",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cstyle\u003E\r\n      form .statement {\r\n        display:block;\r\n        font-weight: bold;\r\n        padding: 30px 0 0 4.25%;\r\n        margin-bottom:10px;\r\n        }\r\n      form .likert {\r\n        list-style:none;\r\n        width:100%;\r\n        margin:0;\r\n        padding:0 0 0;\r\n        display:block;\r\n        }\r\n\r\n      form .likert li {\r\n        display:inline-block;\r\n        width:8%;\r\n        text-align:center;\r\n        vertical-align: top;\r\n        }\r\n\r\n      form .likert li input[type=radio] {\r\n        width: 20px;\r\n        height: 20px;\r\n        display:block;\r\n        position:relative;\r\n        top:0;\r\n        left:50%;\r\n        margin-left:-4px;\r\n        }\r\n\u003C\u002Fstyle\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cbr\u003E\r\n    \u003Cfont size=16\u003E\r\n    \u003Cp\u003E${this.parameters.trait}\u003C\u002Fp\u003E\r\n    \u003C\u002Ffont\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cstyle\u003E\r\nhtml,body {padding:0;margin:0;}\r\n.wrap {\r\n  \r\n}\r\n\r\nform .statement {\r\n  display:block;\r\n  font-size: 1.3rem;\r\n  font-weight: bold;\r\n  padding: 30px 0 0 4.25%;\r\n  margin-bottom:10px;\r\n}\r\nform .likert {\r\n  list-style:none;\r\n  width:100%;\r\n  margin:0;\r\n  padding:0 0 0;\r\n  display:block;\r\n  border-bottom:2px solid #efefef;\r\n}\r\n\r\nform .likert li {\r\n  display:inline-block;\r\n  width:8%;\r\n  text-align:center;\r\n  vertical-align: top;\r\n}\r\n\r\nform .likert li input[type=radio] {\r\n  display:block;\r\n  position:relative;\r\n  top:0;\r\n  left:50%;\r\n  margin-left:-4px;\r\n  \r\n}\r\n\u003C\u002Fstyle\u003E\r\n\r\n\u003Cdiv class=\"wrap\"\u003E\r\n  \u003Ccenter\u003E\r\n  \u003Cform action=\"\"\u003E\r\n    \u003Clabel class=\"statement\"\u003EIs this trait typical of ${this.parameters.oy_left} or ${this.parameters.oy_right} people?\u003C\u002Flabel\u003E\r\n    \u003Cul class='likert'\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"0\"\u003E\r\n        \u003Clabel\u003Every typical of ${this.parameters.oy_left} people\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"1\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"2\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"3\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"4\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"5\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"6\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"7\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"8\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"9\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"10\" required\u003E\r\n        \u003Clabel\u003Every typical of ${this.parameters.oy_right} people\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n    \u003C\u002Ful\u003E\r\n  \u003Clabel class=\"statement\"\u003EHow ${this.parameters.pn_left} or ${this.parameters.pn_right} is this trait?\u003C\u002Flabel\u003E\r\n    \u003Cul class='likert'\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"0\"\u003E\r\n        \u003Clabel\u003Every ${this.parameters.pn_left}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"1\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"2\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"3\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"4\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"5\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"6\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"7\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"8\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"9\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"10\" required\u003E\r\n        \u003Clabel\u003Every ${this.parameters.pn_right}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n    \u003C\u002Ful\u003E\r\n        \u003Clabel class=\"statement\"\u003EHow emotionally intense is this trait?\u003C\u002Flabel\u003E\r\n    \u003Cul class='likert'\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"0\"\u003E\r\n        \u003Clabel\u003E${this.parameters.ar_left}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"1\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"2\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"3\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"4\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"5\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"6\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"7\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"8\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"9\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"10\" required\u003E\r\n        \u003Clabel\u003E${this.parameters.ar_right}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n  \u003C\u002Fform\u003E\r\n  \u003C\u002Fcenter\u003E\r\n\u003C\u002Fdiv\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
debugger
}
                    },
                    "title": "rating_trial_trait"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_rating",
                    "timeout": "500"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 781.75,
                  "height": 389.62,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The first task is now finished.\n\nIn the second task, you will be presented with a number of\nimages showing human faces.\n\nFor each image, you will be presented with three questions about your \nimpression of the face depicted by it.\n\nThere are no right or wrong answers to these questions, so please rely on your personal \nimpression and try to respond as spontaneously as possible.\n\nAfter answering all three questions, please scroll down to the bottom of the page\nand click on the \"Continue\" button to proceed to the next image.\n\nPress the spacebar to start the task.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "instructions_2"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw-shuffle",
                "n": ""
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData.triallist_faces;
} else {
  this.options.templateParameters = this.parent.parameters.triallist_faces;
}
}
              },
              "title": "face_rating_loop",
              "indexParameter": "count_face_ratings",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "sequence_rating",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cstyle\u003E\r\n      form .statement {\r\n        display:block;\r\n        font-weight: bold;\r\n        padding: 30px 0 0 4.25%;\r\n        margin-bottom:10px;\r\n        }\r\n      form .likert {\r\n        list-style:none;\r\n        width:100%;\r\n        margin:0;\r\n        padding:0 0 0;\r\n        display:block;\r\n        }\r\n\r\n      form .likert li {\r\n        display:inline-block;\r\n        width:8%;\r\n        text-align:center;\r\n        vertical-align: top;\r\n        }\r\n\r\n      form .likert li input[type=radio] {\r\n        width: 20px;\r\n        height: 20px;\r\n        display:block;\r\n        position:relative;\r\n        top:0;\r\n        left:50%;\r\n        margin-left:-4px;\r\n        }\r\n\u003C\u002Fstyle\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat2\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.face + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cstyle\u003E\r\nhtml,body {padding:0;margin:0;}\r\n.wrap {\r\n  \r\n}\r\n\r\nform .statement {\r\n  display:block;\r\n  font-size: 1.3rem;\r\n  font-weight: bold;\r\n  padding: 30px 0 0 4.25%;\r\n  margin-bottom:10px;\r\n}\r\nform .likert {\r\n  list-style:none;\r\n  width:100%;\r\n  margin:0;\r\n  padding:0 0 0;\r\n  display:block;\r\n  border-bottom:2px solid #efefef;\r\n}\r\n\r\nform .likert li {\r\n  display:inline-block;\r\n  width:8%;\r\n  text-align:center;\r\n  vertical-align: top;\r\n}\r\n\r\nform .likert li input[type=radio] {\r\n  display:block;\r\n  position:relative;\r\n  top:0;\r\n  left:50%;\r\n  margin-left:-4px;\r\n  \r\n}\r\n\u003C\u002Fstyle\u003E\r\n\r\n\u003Cdiv class=\"wrap\"\u003E\r\n  \u003Ccenter\u003E\r\n  \u003Cform action=\"\"\u003E\r\n    \u003Clabel class=\"statement\"\u003EHow ${this.parameters.oy_left} or ${this.parameters.oy_right} does this face look?\u003C\u002Flabel\u003E\r\n    \u003Cul class='likert'\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"0\"\u003E\r\n        \u003Clabel\u003Every ${this.parameters.oy_left}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"1\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"2\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"3\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"4\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"5\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"6\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"7\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"8\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"9\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"young_old\" value=\"10\" required\u003E\r\n        \u003Clabel\u003Every ${this.parameters.oy_right}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n    \u003C\u002Ful\u003E\r\n  \u003Clabel class=\"statement\"\u003EHow ${this.parameters.pn_left} or ${this.parameters.pn_right} is this face?\u003C\u002Flabel\u003E\r\n    \u003Cul class='likert'\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"0\"\u003E\r\n        \u003Clabel\u003Every ${this.parameters.pn_left}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"1\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"2\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"3\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"4\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"5\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"6\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"7\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"8\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"9\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"pos_neg\" value=\"10\" required\u003E\r\n        \u003Clabel\u003Every ${this.parameters.pn_right}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n    \u003C\u002Ful\u003E\r\n        \u003Clabel class=\"statement\"\u003EHow emotionally intense is this face?\u003C\u002Flabel\u003E\r\n    \u003Cul class='likert'\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"0\"\u003E\r\n        \u003Clabel\u003E${this.parameters.ar_left}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"1\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"2\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"3\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"4\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"5\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"6\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"7\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"8\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"9\"\u003E\r\n        \u003Clabel\u003E\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n            \u003Cli\u003E\r\n        \u003Cinput type=\"radio\" name=\"arousing\" value=\"10\" required\u003E\r\n        \u003Clabel\u003E${this.parameters.ar_right}\u003C\u002Flabel\u003E\r\n      \u003C\u002Fli\u003E\r\n  \u003C\u002Fform\u003E\r\n  \u003C\u002Fcenter\u003E\r\n\u003C\u002Fdiv\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
debugger
}
                    },
                    "title": "rating_trial_face"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_rating",
                    "timeout": "500"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 677.72,
                  "height": 232.33,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The second task is now finished.\n\nNow we have a few short questions about demographic data and about your \nexperience performing the study.\n\n\nPress the space bar to continue.\n\n",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "instructions_3"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "check_socio_demo": "1"
                }
              ],
              "sample": {
                "mode": "draw-shuffle"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "check_loop",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {
                  "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                },
                "title": "sequence_check",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\r\n  \u003Cdiv class=\"w-l text-left\" style=\"display: block\"\u003E\r\n    \r\n    \u003Cform id=\"demography\"\u003E\r\n      \u003Ctable\u003E\r\n        \u003Ctr style=\"height: 50px\"\u003E\r\n          \u003Ctd class=\"font-weight-bold\"\u003E\r\n            How old are you (in years)? (please use numbers only)\r\n          \u003C\u002Ftd\u003E\r\n          \u003Ctd\u003E\r\n            \u003Cinput name=\"age\" type=\"number\" required class=\"w-100\" min=\"18\" max=\"120\"\u003E\r\n          \u003C\u002Ftd\u003E\r\n        \u003C\u002Ftr\u003E\r\n        \r\n        \u003C!-- Column balance --\u003E\r\n        \u003Ccolgroup\u003E\r\n          \u003Ccol style=\"width: 45%\"\u003E\r\n          \u003Ccol style=\"width: 65%\"\u003E\r\n        \u003C\u002Fcolgroup\u003E\r\n      \u003C\u002Ftable\u003E\r\n    \u003C\u002Fform\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fmain\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EContinue\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "age"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "What is your biological sex?",
                        "content": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"male\" name=\"sex\" value=\"0\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"male\"\u003Emale\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"female\" name=\"sex\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"female\"\u003Efemale\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"kA\" name=\"sex\" value=\"2\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"kA\"\u003EI don't want to answer this question.\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "sex"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Which gender do you identify with?",
                        "content": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"male\" name=\"gender\" value=\"0\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"male\"\u003Emale\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"female\" name=\"gender\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"female\"\u003Efemale\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"diverse\" name=\"gender\" value=\"2\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"diverse\"\u003Eother\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"kA\" name=\"gender\" value=\"3\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"kA\"\u003EI don't want to answer this question.\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "gender"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Did you pay attention to the words and images presented throughout the entire study?",
                        "content": "(the response to this question will not affect your payment)"
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"yes\" name=\"pay_attention\" value=\"1\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"yes\"\u003EYes.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"no\" name=\"pay_attention\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"no\"\u003ENo.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "pay_attention"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "It would be very helpful if you could tell us at this point whether you have taken the requested responses seriously, so that we can use your answers for our scientific analysis, or whether you were just clicking through to take a look at the survey?",
                        "content": "(again, this will not affect your payment)\n"
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"serious\" name=\"serious\" value=\"1\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"serious\"\u003EI have taken the requested responses seriously.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"not_serious\" name=\"serious\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"not_serious\"\u003EI have just clicked through, please discard my data.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "seriousness"
                  }
                ]
              }
            },
            {
              "type": "lab.html.Page",
              "items": [
                {
                  "type": "text",
                  "title": "If you have any comments, feel free to include them below:"
                },
                {
                  "required": false,
                  "type": "textarea",
                  "name": "comment_study"
                }
              ],
              "scrollTop": true,
              "submitButtonText": "Continue →",
              "submitButtonPosition": "right",
              "files": {},
              "responses": {
                "": "comment"
              },
              "parameters": {},
              "messageHandlers": {
                "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
              },
              "title": "comment"
            },
            {
              "type": "lab.html.Screen",
              "files": {},
              "responses": {
                "keypress(Space)": "end_study"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "end_study_redirect",
              "content": " \u003Cmain class=\"content-vertical-center\r\n             content-horizontal-center\"\u003E\r\n \u003Cdiv style=\"font-size: 1.2vw; width: 70%;\"\u003E  \r\n\u003Cp style=\"text-align: justify;\"\u003EThis study is now over. Thank you very much for your participation!\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EIf you have any question or comment, or if you would like to receive additional information on the present study, please do not hesitate to contact the person in charge of this research at the following e-mail address: karoline.bading@uni-tuebingen.de\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003E\u003Cb\u003EPress the spacebar to be redirected to Prolific.\u003C\u002Fb\u003E\u003C\u002Fp\u003E\r\n\r\n \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fmain\u003E"
            }
          ]
        }
      ]
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())