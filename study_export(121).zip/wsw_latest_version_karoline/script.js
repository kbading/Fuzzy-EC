// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "WSW_latest_version_Karoline",
    "description": "27th of January, KB, following changes:\n-buttons in German in memory test\n-full_screen in German\n-NA for variable 'us' for distractors (instead of \" \") --\u003E useful for R\n\n26th of January, KB, following changes:\n- corrected a typo on learning_end slide\n\n25th of January, JB, following changes:\n- tried to improve the buttons of the check loop items\n\n25th of January, KB, following changes:\n- adapted how us_valence and cs_category are represented in triallist and triallist_learning\n-added slides for age, gender and attention\u002Fseriousness during participation\n-added a blueprint for participation code generation (in case we need it)\n\n25th of January, JB, following changes:\n\n- uploaded USs and resized CSs in the static rather than in separate items and adapted how to call the pictures in the three tasks\n- changed the number of cs_male and cs_female (i.e., 24 items instead of 30)\n- simplified the learning phase, study flow, and item names\n- adapted recognition screen\n- buttons conditionally appear in the recognition\u002Fsource memory and rating tasks\n- reworked a bit how CSs and USs and response options are displayed in all phases\n- adapted the breaks in the learning phase\n- renamed some internal variables (in html forms; in behavior screens)\n- resized instructions (20 everywhere)\n- \"test\" mode: only 6 trials (learning; memory; ratings) -- defined in the script of the \"full_screen\" item\n- CSS code added in \"settings\"\n- ITI between recognition and US identity memory: from 1000ms to 500ms\n- cursor removed in learning phase\n- Instructions added (as of 25th of January)\n\nThis version was written by Karoline on January 25th 2023.\nThe following remains to be done: \n- adding instructions for all parts of the experiment\n- \"clean\" code and interfaces (e.g. clicking on images instead of buttons in the memory task)\n- adding resized images",
    "repository": "",
    "contributors": "\n"
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
// retrieve prolific pic
if (typeof jatos !== "undefined") {
   this.data.prolific_pid = jatos.urlQueryParameters.PROLIFIC_PID;
}

this.parameters.n_learn = 144 //24*6=144 but 6 for test
this.parameters.n_mem = 48 //48 but 6 for test
this.parameters.n_ratings = 48 //48 but 6 for test

const male_cs = ['m1','m2','m3','m4','m5','m6','m7','m8','m9','m10','m11','m12','m13','m14','m15','m16','m17','m18','m19','m20','m21','m22','m23','m24']

const female_cs = ['f1','f2','f3','f4','f5','f6','f7','f8','f9','f10','f11','f12','f13','f14','f15','f16','f17','f18','f19','f20','f21','f22','f23','f24']

const pos_us = ['p1','p2','p3','p4','p5','p6','p7','p8','p9','p10','p11','p12']
 
const neg_us = ['n1','n2','n3','n4','n5','n6','n7','n8','n9','n10','n11','n12']

var us_pos = this.random.shuffle(pos_us)
var us_neg = this.random.shuffle(neg_us)
var cs_male = this.random.shuffle(male_cs)
var cs_female = this.random.shuffle(female_cs)

var us_valences = ['positive','negative','dist']
var cs_sex = ['male','female','']
var na_vec = ['NA']

var triallist = [];
var dists = [];

for (var i=0 ; i < 6; i++) {
  console.log(us_pos)
  console.log(us_neg)
  triallist[i] = new Object();
// fixation cross trial?
  triallist[i].us_valence = us_valences[0];
  triallist[i].cs_category = cs_sex[0];
  //cs and us
  triallist[i].cs = cs_male[i];
  triallist[i].us = us_pos[i];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7])
  //first select targetpos
  triallist[i].idtarg = pos[0]
  // assign target and distracter images
  dists_pos = us_pos.slice(0,12);
  console.log(dists_pos);
  dists_pos.splice(i,1);
  console.log(dists_pos);
  dists_neg = us_neg.slice(0,12)
  console.log(dists_neg);
  dists_pos = this.random.shuffle(dists_pos);
  console.log(dists_pos);
  dists_neg = this.random.shuffle(dists_neg);
  console.log(dists_neg);
  dists_pos = dists_pos.slice(0,3);
  console.log(dists_pos);
  dists_neg = dists_neg.slice(0,4);
  console.log(dists_neg);
  dists = dists_pos.concat(dists_neg);
  console.log(dists);
  dists = this.random.shuffle(dists);
  console.log(dists);
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
};

for ( var i=6 ; i < 12; i++) {
  triallist[i] = new Object();
  // fixation cross trial?
  triallist[i].us_valence = us_valences[1];
  triallist[i].cs_category = cs_sex[0];
  //cs and us (remove 'static/' to reduce data file size)
  triallist[i].cs = cs_male[i];
  triallist[i].us = us_neg[i-6];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7])
  //first select targetpos
  triallist[i].idtarg = pos[0]
  // assign target and distracter images
  dists_neg = us_neg.slice(0,12);
  dists_neg.splice(i-6,1);
  dists_pos = us_pos.slice(0,12);
  dists_neg = this.random.shuffle(dists_neg);
  dists_pos = this.random.shuffle(dists_pos);
  dists_neg = dists_neg.slice(0,3);
  dists_pos = dists_pos.slice(0,4);
  dists = dists_pos.concat(dists_neg);
  dists = this.random.shuffle(dists);
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
};

for ( var i=12 ; i < 18; i++) {
  triallist[i] = new Object();
  // fixation cross trial?
  triallist[i].us_valence = us_valences[0];
  triallist[i].cs_category = cs_sex[1];
  //cs and us (remove 'static/' to reduce data file size)
  triallist[i].cs = cs_female[i-12];
  triallist[i].us = us_pos[i-6];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7])
  //first select targetpos
  triallist[i].idtarg = pos[0]
  // assign target and distracter images
  dists_pos = us_pos.slice(0,12);
  dists_pos.splice(i-6,1);
  dists_neg = us_neg.slice(0,12);
  dists_pos = this.random.shuffle(dists_pos);
  dists_neg = this.random.shuffle(dists_neg);
  dists_pos = dists_pos.slice(0,3);
  dists_neg = dists_neg.slice(0,4);
  dists = dists_pos.concat(dists_neg);
  dists = this.random.shuffle(dists);
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
};

for ( var i=18 ; i < 24; i++) {
  triallist[i] = new Object();
  // fixation cross trial?
  triallist[i].us_valence = us_valences[1];
  triallist[i].cs_category = cs_sex[1];
  //cs and us (remove 'static/' to reduce data file size)
  triallist[i].cs = cs_female[i-12];
  triallist[i].us = us_neg[i-12];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7])
  //first select targetpos
  triallist[i].idtarg = pos[0]
  // assign target and distracter images
  dists_neg = us_neg.slice(0,12);
  dists_neg.splice(i-12,1);
  dists_pos = us_pos.slice(0,12);
  dists_neg = this.random.shuffle(dists_neg);
  dists_pos = this.random.shuffle(dists_pos);
  dists_neg = dists_neg.slice(0,3);
  dists_pos = dists_pos.slice(0,4);
  dists = dists_pos.concat(dists_neg);
  dists = this.random.shuffle(dists);
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
};

for ( var i=24 ; i < 36; i++) {
  triallist[i] = new Object();
  // fixation cross trial?
  triallist[i].us_valence = us_valences[2];
  triallist[i].cs_category = cs_sex[0];
  //cs and us (remove 'static/' to reduce data file size)
  triallist[i].cs = cs_male[i-12];
  triallist[i].us = na_vec[0];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7])
  // assign target and distracter images
  dists_pos = us_pos.slice(0,12);
  dists_neg = us_neg.slice(0,12);
  dists_pos = this.random.shuffle(dists_pos);
  dists_neg = this.random.shuffle(dists_neg);
  dists_pos = dists_pos.slice(0,4);
  dists_neg = dists_neg.slice(0,4);
  dists = dists_pos.concat(dists_neg);
  dists = this.random.shuffle(dists);
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = dists[0];
  triallist[i].uss[pos[1]] = dists[1];
  triallist[i].uss[pos[2]] = dists[2];
  triallist[i].uss[pos[3]] = dists[3];
  triallist[i].uss[pos[4]] = dists[4];
  triallist[i].uss[pos[5]] = dists[5];
  triallist[i].uss[pos[6]] = dists[6];
  triallist[i].uss[pos[7]] = dists[7];
};

for ( var i=36 ; i < 48; i++) {
  triallist[i] = new Object();
  // fixation cross trial?
  triallist[i].us_valence = us_valences[2];
  triallist[i].cs_category = cs_sex[1];
  //cs and us (remove 'static/' to reduce data file size)
  triallist[i].cs = cs_female[i-24];
  triallist[i].us = na_vec[0];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7])
  // assign target and distracter images
  dists_pos = us_pos.slice(0,12);
  dists_neg = us_neg.slice(0,12);
  dists_pos = this.random.shuffle(dists_pos);
  dists_neg = this.random.shuffle(dists_neg);
  dists_pos = dists_pos.slice(0,4);
  dists_neg = dists_neg.slice(0,4);
  dists = dists_pos.concat(dists_neg);
  dists = this.random.shuffle(dists);
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = dists[0];
  triallist[i].uss[pos[1]] = dists[1];
  triallist[i].uss[pos[2]] = dists[2];
  triallist[i].uss[pos[3]] = dists[3];
  triallist[i].uss[pos[4]] = dists[4];
  triallist[i].uss[pos[5]] = dists[5];
  triallist[i].uss[pos[6]] = dists[6];
  triallist[i].uss[pos[7]] = dists[7];
};

triallist_learning = triallist.slice(0,24)

if(typeof(jatos) != 'undefined'){
  //jatos.studySessionData.triallist = triallist;
  jatos.setStudySessionData(triallist);
  jatos.setStudySessionData(triallist_learning);
} else {
  this.parent.parameters.triallist = triallist;
  this.parent.parameters.triallist_learning = triallist_learning;
}

console.log(triallist_learning)
console.log(triallist)
}
      },
      "title": "full_screen",
      "plugins": [
        {
          "type": "fullscreen",
          "message": "Dieses Experiment erfordert Vollbildmodus.",
          "hint": "Bitte klicken, um im Vollbildmodus fortzufahren.",
          "path": "lab.plugins.Fullscreen"
        }
      ],
      "content": [
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "image",
              "src": "${ this.files[\"Bildmarke_black_8cm.jpg\"] }",
              "name": ""
            },
            {
              "type": "text",
              "title": "Teilnahmebedingungen und Einwilligungserklärung",
              "content": "\u003Cp\u003ELiebe Teilnehmerin, lieber Teilnehmer,\u003C\u002Fp\u003E\n\u003Cp style=\"text-align:justify;\"\u003Evielen Dank für Dein Interesse an der Studie!\u003C\u002Fp\u003E\n\u003Cp style=\"text-align:justify;\"\u003EBitte lies Dir die folgenden Informationen sorgfältig durch und entscheide dann, ob Du an der Studie teilnehmen möchtest oder nicht.\u003C\u002Fp\u003E\n\n\u003Cp style=\"text-align:justify;\"\u003EWir sind WissenschaftlerInnen an der Friedrich-Schiller-Universität Jena und möchten untersuchen, wie Menschen Eindrücke und Meinungen von neuartigen Objekten bilden. Wir hoffen, dass unsere Ergebnisse das Wissen über psychologische Prozesse der Eindrucksbildung erweitern werden.\u003C\u002Fp\u003E\n\n\u003Cp style=\"text-align:justify;\"\u003EDie Studienteilnahme dauert circa 30 Minuten. Wenn Du Psychologie an der FSU Jena studierst, kannst Du Dir für die vollständige Teilnahme 0.5 Versuchspersonenstunden anrechnen lassen. Den Absolvierungscode zur Verbuchung im Versuchspersonenstundenserver kannst Du am Ende der Studie generieren.\u003C\u002Fp\u003E\n\n\u003Cp style=\"text-align: justify;\"\u003EFür die Studienteilnahme solltest Du Deutsch auf C2- oder Muttersprachniveau sprechen und einen festen Rechner oder Laptop verwenden (kein Tablet oder Smartphone). Falls Du eine Sehhilfe benötigst, trage diese bitte während der gesamten Studiendauer.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EDie Studienteilnahme hat keine uns bekannten Risiken. Es gibt auch keine richtigen oder falschen Antworten. Wir bitten Dich daher, alle Aufgaben ehrlich und gewissenhaft zu bearbeiten. Die Studienteilnahme ist komplett anonym: Keine Deiner Antworten kann mit Dir persönlich in Verbindung gebracht werden.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EDeine Antworten werden auf einer passwortgeschützten Festplatte gesammelt und bis zur Veröffentlichung gespeichert. Anschließend wird eine Datei mit Deinen anonymen Antworten in einem sicheren Online-Archiv (Open Science Framework) gespeichert werden. Diese Datei wird anderen Forschenden ohne zeitliche Begrenzung zur Verfügung stehen. \u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EDie Teilnahme an unserer Studie ist komplett freiwillig. Du kannst die Teilnahme an der Studie jederzeit und ohne Angabe von Gründen beenden (durch Drücken der Esc-Taste), ohne dass Dir daraus Nachteile entstehen.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EBist Du mit den oben beschriebenen Teilnahmebedingungen einverstanden und möchtest an der Studie teilnehmen?\u003C\u002Fp\u003E"
            },
            {
              "required": true,
              "type": "html",
              "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"consent_yes\" name=\"consent\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\" required\u003E\r\n  \u003Clabel for=\"consent_yes\"\u003EJa, ich bin einverstanden und möchte an der Studie teilnehmen.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"consent_no\" name=\"consent\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"consent_no\"\u003ENein, ich bin nicht einverstanden und möchte nicht an der Studie teilnehmen.\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EBeginnen!\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Ccenter\u003E",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "hidden",
          "files": {
            "Bandeau+new+logo+2019.jpg": "embedded\u002F5ffb7db9f15ad3b748ba63804367e87b2d52bf35af7d1cc696d84ef88aad1724.jpg",
            "Bildmarke_black_8cm.jpg": "embedded\u002F8d8205d13605ad5501ddcda7ec381eee3d98b9baf404875950775025a8c6f1bc.jpg"
          },
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "consent",
          "width": "l"
        },
        {
          "type": "lab.canvas.Screen",
          "content": [
            {
              "type": "i-text",
              "left": 0,
              "top": 0,
              "angle": 0,
              "width": 584.81,
              "height": 101.25,
              "stroke": null,
              "strokeWidth": 1,
              "fill": "black",
              "text": "Du hast Dich entschieden, doch nicht an der Studie teilzunehmen.\nTrotzdem vielen Dank für Dein Interesse.\n\nDrücke nun die Esc-Taste, um die Teilnahme zu beenden.",
              "fontStyle": "normal",
              "fontWeight": "normal",
              "fontSize": "20",
              "fontFamily": "sans-serif",
              "lineHeight": 1.16,
              "textAlign": "center"
            }
          ],
          "viewport": [
            800,
            600
          ],
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "if_consent_no",
          "tardy": true,
          "skip": "${this.state.consent!=0}"
        },
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "if_consent_yes",
          "tardy": true,
          "skip": "${this.state.consent!= 1}",
          "content": [
            {
              "type": "lab.html.Page",
              "items": [
                {
                  "type": "text",
                  "title": "Bevor es losgeht ...",
                  "content": "\u003Cp\u003EBevor Du beginnst, schalte bitte Dein Handy\u002FE-Mail\u002FMusik aus, sodass Du Dich voll auf die Studie konzentrieren kannst.\u003C\u002Fp\u003E\n\n\u003Cp\u003EVerwende bitte außerdem einen COMPUTER oder LAPTOP (kein Handy oder Tablet), um die Studie zu bearbeiten.\u003C\u002Fp\u003E\n\n\u003Cp\u003EDanke!\u003C\u002Fp\u003E"
                },
                {
                  "required": true,
                  "type": "html",
                  "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n  \u003Cform\u003E\r\n\u003Cdiv id=\"weiterdiv\"\u003E\u003Cbutton id=\"end\"\u003ELos geht's!\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fform\u003E\r\n\u003C\u002Fcenter\u003E",
                  "name": ""
                }
              ],
              "scrollTop": true,
              "submitButtonText": "Los geht's!",
              "submitButtonPosition": "hidden",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "before_you_start",
              "width": "l"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 674.71,
                  "height": 232.33,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Herzlich Willkommen zum Experiment und vielen Dank für Deine Teilnahme!\n\nDas Experiment besteht aus drei Teilen und wird circa 30 Minuten dauern.\n\nBitte lies Dir die folgenden Instruktionen aufmerksam durch und bearbeite\nalle Teile des Experiments konzentriert und gewissenhaft.\n\n\nWeiter mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "general_instructions_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "general_instructions"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 584.76,
                  "height": 284.76,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Im ersten Teil des Experiments werden Dir Bildpaare präsentiert.\n\nJedes Bildpaar besteht aus einem Gesicht und einer Szenerie.\n\nDeine Aufgabe ist ganz einfach:\n\nDu sollst die Bildpaare aufmerksam betrachten und Dir einprägen,\nwelches Gesicht mit welcher Szenerie gepaart wird.\n\n\nWeiter mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "learning_instructions_1"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 644.8,
                  "height": 232.33,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Als Nächstes werden Dir die Bildpaare nacheinander präsentiert.\n\nBitte betrachte die Bildpaare aufmerksam und versuche Dir einzuprägen,\nwelches Gesicht mit welcher Szenerie gepaart wird.\n\nDieser Teil des Experiments wird circa 6 Minuten dauern und Du hast\nzwischendurch die Möglichkeit, kurze Pausen einzulegen.\n\nBereit? Dann los mit der Leertaste!",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_2"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "learning_instructions_2"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw",
                "n": "${Math.min(144, this.parameters.n_learn)}"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData;
} else {
  this.options.templateParameters = this.parent.parameters.triallist_learning;
}
}
              },
              "title": "learning_loop",
              "tardy": true,
              "indexParameter": "count_trial_learning",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {
                  "run": function anonymous(
) {
//remove mouse
document.body.style.cursor = 'none' 
}
                },
                "title": "learning_sequence",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "image",
                        "left": -125,
                        "top": 0,
                        "angle": 0,
                        "width": 150,
                        "height": 200.54,
                        "stroke": null,
                        "strokeWidth": 0,
                        "fill": "black",
                        "src": "${ 'static\u002F' + this.parameters.cs + '.jpg' }"
                      },
                      {
                        "type": "image",
                        "left": 125,
                        "top": 0,
                        "angle": 0,
                        "width": 250,
                        "height": 200,
                        "stroke": null,
                        "strokeWidth": 0,
                        "fill": "black",
                        "src": "${ 'static\u002F' + this.parameters.us + '.jpg' }"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "learning_trial",
                    "timeout": "2500"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_learning",
                    "timeout": "1000"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 458,
                        "height": 153.68,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "33 Prozent der Bildpaare sind nun geschafft!\n\nDu kannst jetzt eine kurze Pause einlegen.\n\n\nDrücke die Leertaste, wenn Du fortfahren möchtest.",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "20",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress(Space)": "break_end"
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "learning_break_1",
                    "tardy": true,
                    "skip": "${ this.state.count_trial_learning != 47 }"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 458,
                        "height": 153.68,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "66 Prozent der Bildpaare sind nun geschafft!\n\nDu kannst jetzt eine kurze Pause einlegen.\n\n\nDrücke die Leertaste, wenn Du fortfahren möchtest.",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "20",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress(Space)": "break_end"
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "learning_break_2",
                    "tardy": true,
                    "skip": "${ this.state.count_trial_learning != 95 }"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 551.43,
                  "height": 179.9,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Der erste Teil des Experiments ist geschafft!\n\nDu hast nun alle Bildpaare betrachtet und kannst jetzt mit dem\nzweiten Teil des Experiments fortfahren.\n\n\nWeiter geht's mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_end"
              },
              "parameters": {},
              "messageHandlers": {
                "commit": function anonymous(
) {
//show mouse again
document.body.style.cursor = 'default'
}
              },
              "title": "learning_end"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 653.6,
                  "height": 415.84,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Im zweiten Teil des Experiments werden Dir einzeln Gesichter präsentiert.\n\nEinige dieser Gesichter werden Dir bekannt sein,\nda sie Teil der zuvor präsentierten Bildpaare waren.\n\nAndere Gesichter werden Dir unbekannt sein,\nda sie nicht Teil der Bildpaare waren und bisher nicht präsentiert wurden.\n\nDeine Aufgabe ist wieder einfach:\n\nDu sollst für jedes Gesicht angeben, \nob es sich um ein bekanntes (also zuvor präsentiertes) oder \num ein unbekanntes (also zuvor nicht präsentiertes) Gesicht handelt.\n\n\nWeiter mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "memory_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "memory_instructions_1"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 716.63,
                  "height": 415.84,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Wenn Du ein Gesicht als bekannt (also zuvor präsentiert) einstufst,\nwirst Du noch eine zweite Aufgabe bekommen.\n\nDir werden dann acht Szenerien präsentiert und Du sollst angeben,\nmit welcher der acht Szenerien das jeweilige Gesicht zuvor gepaart wurde.\n\nWenn Du Dich an die zuvor gepaarte Szenerie erinnern kannst,\nklicke auf das entsprechende Bild und danach auf „Weiter“.\n\nWenn Du Dich nicht erinnern kannst, mit welcher der acht Szenerien ein Gesicht \ngepaart wurde, dann versuche die zuvor gepaarte Szenerie zu erraten. \nKlicke dazu auf das entsprechende Bild und danach auf „Weiter“.\n\n\n\nBereit? Dann weiter mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "memory_instructions_2"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "memory_instructions_2"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw-shuffle",
                "n": "${Math.min(48, this.parameters.n_mem)}"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData;
} else {
  this.options.templateParameters = this.parent.parameters.triallist;
}
}
              },
              "title": "memory_loop",
              "indexParameter": "count_trial_memory",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "memory_sequence",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_memory_1",
                    "timeout": "500"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.cs + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"task\" id=\"recognition_memory\"\u003E\u003C\u002Fdiv\u003E\r\n\r\n\u003Cform\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n    \u003Cdiv class=\"mem\"\u003E\r\n        \u003Cinput type=\"radio\" id=\"old\" name=\"reco_resp\" value=\"old\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"old\"\u003EJa (bekannt)\u003C\u002Flabel\u003E      \r\n\r\n        \u003Cinput type=\"radio\" id=\"new\" name=\"reco_resp\" value=\"new\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n        \u003Clabel for =\"new\"\u003ENein (unbekannt)\u003C\u002Flabel\u003E      \r\n    \u003C\u002Fdiv\u003E\r\n \u003C\u002Fdiv\u003E\r\n \u003C\u002Fcenter\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"reco\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\r\n\u003C\u002Fform\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
debugger
}
                    },
                    "title": "recognition_trial"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_memory_2",
                    "timeout": "500",
                    "tardy": true,
                    "skip": "${this.state.reco_resp!=\"old\"}"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.cs + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"task\" id=\"source_memory\"\u003E\u003C\u002Fdiv\u003E\r\n\r\n\u003Cform\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n    \u003Cdiv class=\"mem\"\u003E\r\n        \u003Cinput type=\"radio\" id=\"id1\" name=\"source_mem\" value=\"us1\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id1\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[0] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E   \r\n\r\n        \u003Cinput type=\"radio\" id=\"id2\" name=\"source_mem\" value=\"us2\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id2\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[1] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id3\" name=\"source_mem\" value=\"us3\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id3\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[2] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id4\" name=\"source_mem\" value=\"us4\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id4\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[3] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E \r\n\r\n          \u003Cbr\u003E\r\n        \r\n         \u003Cinput type=\"radio\" id=\"id5\" name=\"source_mem\" value=\"us5\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id5\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[4] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id6\" name=\"source_mem\" value=\"us6\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id6\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[5] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id7\" name=\"source_mem\" value=\"us7\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n        \u003Clabel for =\"id7\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[6] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E    \r\n\r\n        \u003Cinput type=\"radio\" id=\"id8\" name=\"source_mem\" value=\"us8\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n        \u003Clabel for =\"id8\"\u003E\u003Cimg src=\"${ 'static\u002F' + this.parameters.uss[7] + '.jpg'}\"\u003E\u003C\u002Flabel\u003E      \r\n    \u003C\u002Fdiv\u003E\r\n \u003C\u002Fdiv\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"source\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\r\n \u003C\u002Fcenter\u003E\r\n\u003C\u002Fform\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "source_trial",
                    "tardy": true,
                    "skip": "${this.state.reco_resp!=\"old\"}"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 514.66,
                  "height": 75.03,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Der zweite Teil des Experiments ist nun geschafft.\n\nDrücke die Leertaste, um mit dem dritten Teil fortzufahren.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "memory_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "memory_end"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 833.44,
                  "height": 337.19,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Im dritten Teil des Experiments werden Dir nochmal die bekannten\nund unbekannten Gesichter präsentiert.\n\nDiesmal sollst Du für jedes Gesicht angeben, wie positiv bzw. negativ\nDu das jeweilige Gesicht findest.\n\nNutze dafür die unterhalb des Gesichts präsentierte 11-stufige Skala und klicke auf den Punkt,\nwelcher Deine Bewertung des Gesichts am besten widerspiegelt.\nKlicke danach auf \"Weiter\", um mit dem nächsten Gesicht fortzufahren.\n\n\n\nBereit? Dann weiter mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "ratings_instructions"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "rating_instructions"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw-shuffle",
                "n": "${Math.min(48, this.parameters.n_ratings)}"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData;
} else {
  this.options.templateParameters = this.parent.parameters.triallist;
}
}
              },
              "title": "rating_loop",
              "indexParameter": "count_trial_ratings",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "sequence_rating",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cstyle\u003E\r\n      form .statement {\r\n        display:block;\r\n        font-weight: bold;\r\n        padding: 30px 0 0 4.25%;\r\n        margin-bottom:10px;\r\n        }\r\n      form .likert {\r\n        list-style:none;\r\n        width:100%;\r\n        margin:0;\r\n        padding:0 0 0;\r\n        display:block;\r\n        }\r\n\r\n      form .likert li {\r\n        display:inline-block;\r\n        width:8%;\r\n        text-align:center;\r\n        vertical-align: top;\r\n        }\r\n\r\n      form .likert li input[type=radio] {\r\n        display:block;\r\n        position:relative;\r\n        top:0;\r\n        left:50%;\r\n        margin-left:-4px;\r\n        }\r\n\u003C\u002Fstyle\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.cs + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"task\" id=\"ratings\"\u003E\u003C\u002Fdiv\u003E\r\n\r\n  \u003Cul class='likert'\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E -5 (sehr negativ)\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E-4\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"2\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E-3\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"3\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E-2\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"4\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E-1\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"5\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E0\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"6\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E+1\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"7\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E+2\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"8\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E+3\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"9\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\"\u003E\r\n      \u003Clabel\u003E+4\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n      \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"10\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible'\" required\u003E\r\n      \u003Clabel\u003E+5 (sehr positiv)\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n  \u003C\u002Ful\u003E\r\n\r\n    \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"source\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fcenter\u003E\r\n",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
debugger
}
                    },
                    "title": "rating_trial"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_rating",
                    "timeout": "500"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 521,
                  "height": 153.68,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Der dritte und letzte Teil des Experiments ist nun geschafft.\n\nWir haben jetzt noch ein paar Fragen zu Deiner Person.\n\n\nWeiter mit der Leertaste.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "ratings_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "rating_end"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "check_socio_demo": "1"
                }
              ],
              "sample": {
                "mode": "draw-shuffle"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "check_loop",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {
                  "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                },
                "title": "sequence_check",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "",
                        "content": "Wie alt bist Du (in Jahren)?"
                      },
                      {
                        "required": true,
                        "type": "textarea",
                        "name": "age"
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "age"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Welchem Geschlecht fühlst Du Dich zugehörig?",
                        "content": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"male\" name=\"gender\" value=\"0\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"male\"\u003Emännlich\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"female\" name=\"gender\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"female\"\u003Eweiblich\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"diverse\" name=\"gender\" value=\"2\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"diverse\"\u003Edivers\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"kA\" name=\"gender\" value=\"3\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"kA\"\u003Ekeine Angabe\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "gender"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Hast Du während der gesamten Studie aufmerksam auf die dargestellten Bilder geachtet? ",
                        "content": "(Diese Angabe hat keine Auswirkung auf Deine Vergütung.)"
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"yes\" name=\"pay_attention\" value=\"1\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"yes\"\u003EJa.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"no\" name=\"pay_attention\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"no\"\u003ENein.\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "pay_attention"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Es wäre sehr hilfreich, wenn Du uns an dieser Stelle mitteilst, ob Du die Aufgaben ernst genommen hast, damit wir Deine Antworten für unsere wissenschaftliche Analyse verwenden können, oder ob Du Dich nur durchgeklickt hast, um Dir die Studie anzuschauen.",
                        "content": "(Diese Angabe hat keine Auswirkung auf Deine Vergütung.)\n"
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"serious\" name=\"serious\" value=\"1\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"serious\"\u003EIch habe die Aufgaben ernst genommen.\r\n\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"not_serious\" name=\"serious\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"not_serious\"\u003EIch habe mich nur durchgeklickt, bitte verwerft meine Daten.\r\n\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "seriousness"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Vielen Dank für die Teilnahme an unserer Studie! ",
                        "content": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\r\n\u003Cdiv style=\"font-size: 1.2vw\"\u003E  \r\n\u003Cp style=\"text-align: justify;\"\u003EMit der Studie wollten wir untersuchen, ob Deine Einstellung zu den Gesichtern durch die Valenz der gepaarten Szenerie (positiv vs. negativ) beeinflusst wird. Außerdem wollten wir wissen, ob deine Einstellung zu den Gesichtern davon abhängt, ob Du Dich an die gepaarte Szenerie erinnern kannst.\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EFalls Du noch Fragen zur Studie hast, kannst Du Dich gerne an karoline.bading@uni-jena.de wenden.\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EWenn Du an der FSU Jena Psychologie studierst und für die Teilnahme mit 0.5 VP-Stunden vergütet werden möchtest, kannst Du im nächsten Schritt einen Absolvierungscode für die Verbuchung im VPHS generieren. ACHTUNG: Die Absolvierungscodes werden erst nach Abschluss der Datenerhebung (Ende Februar 2023) im VPHS freigeschaltet. Eine Verbuchung Deiner 0.5 VP-Stunden wird also erst ab Anfang März 2023 möglich sein.\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EHast Du noch irgendwelche Fragen oder Anmerkungen, die Du uns mitteilen möchtest? Dann trage sie gerne in das folgende Textfeld ein.\u003C\u002Fp\u003E\r\n\r\n \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fmain\u003E",
                        "name": ""
                      },
                      {
                        "required": false,
                        "type": "input",
                        "name": "comment_study"
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "debriefing_and_comment",
                    "skip": true
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Möchtest Du einen Absolvierungscode generieren?",
                        "content": "Mit diesem kannst Du dann Deine Teilnahme auf dem Versuchspersonenstundenserver VPHS verbuchen.\nFür die Teilnahme erhältst Du 0.5 VP-Stunden."
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"VP_yes\" name=\"vp_code\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\" required\u003E\r\n  \u003Clabel for=\"VP_yes\"\u003EJa, möchte ich.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n\r\n  \u003Cinput type=\"radio\" id=\"VP_no\" name=\"vp_code\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"VP_no\"\u003ENein, möchte ich nicht.\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Ccenter\u003E\r\n\r\n\u003C\u002Fform\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {
                      "Bandeau+new+logo+2019.jpg": "embedded\u002F5ffb7db9f15ad3b748ba63804367e87b2d52bf35af7d1cc696d84ef88aad1724.jpg",
                      "Bildmarke_black_8cm.jpg": "embedded\u002F8d8205d13605ad5501ddcda7ec381eee3d98b9baf404875950775025a8c6f1bc.jpg"
                    },
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "VP_Stunde",
                    "width": "l",
                    "skip": true
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Als Nächstes musst Du Deinen persönlichen Absolvierungscode erstellen und in das Textfeld eintragen.",
                        "content": "Der Absolvierungscode setzt sich aus drei Komponenten zusammen.\n\n\n\n\n"
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Die erste Komponente lautet: 181_"
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Die zweite Komponente sind die ersten drei Buchstaben Deines Geburtsorts (in Großbuchstaben)."
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Die dritte Komponente sind die letzten drei Ziffern Deiner Handynummer."
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "BEISPIEL: Für eine Person mit Geburtsort Hamburg und Handynummer 0163-78965498 lautet der Code: 181_HAM498"
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Erstelle nun bitte Deinen persönlichen Code (basierend auf obigen Regeln), notiere ihn Dir für die Verbuchung im VPHS (ab Februar 2023) und trage ihn dann in das folgende Textfeld ein."
                      },
                      {
                        "required": true,
                        "type": "textarea",
                        "name": "code"
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "generate_code",
                    "tardy": true,
                    "skip": true
                  }
                ]
              }
            },
            {
              "type": "lab.html.Screen",
              "files": {},
              "responses": {
                "keypress(Space)": "end_study"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "end_study_redirect",
              "content": " \u003Cmain class=\"content-vertical-center\r\n             content-horizontal-center\"\u003E\r\n \u003Cdiv style=\"font-size: 1.2vw; width: 70%;\"\u003E  \r\n\u003Cp style=\"text-align: justify;\"\u003EDie Studie ist jetzt abgeschlossen! Vielen Dank für Deine Teilnahme!\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EDrücke nun UNBEDINGT die Leertaste, um das Programm zu beenden und Deine (anonymen) Daten an unseren Server zu schicken. Danach kannst Du das Browserfenster schließen.\u003C\u002Fp\u003E\r\n \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fmain\u003E"
            }
          ]
        }
      ]
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())