// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "study_program_EC_who_said_what_paradigm_Exp2",
    "description": "Specificity of memory for unconditioned stimuli in Evaluative Conditioning procedures: A Multinomial Processing Tree modeling approach -- Experiment 2 (adjectives and faces).\n\nVersion 2 -- NEED TO DO: \n- check the entire study program",
    "repository": "",
    "contributors": "Karoline Bading\nJérémy Béna\nKlaus Rothermund\n"
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "image",
          "src": "${ this.files[\"UT_WBMW_Rot_RGB_01-1024x263(2).png\"] }",
          "width": "600",
          "height": "150",
          "name": ""
        },
        {
          "type": "text",
          "title": "\u003Ccenter\u003EConsent form to take part in the study entitled “impressions of novel faces” conducted online on Prolific\u003C\u002Fcenter\u003E",
          "content": "\u003Cp\u003EDear participant,\u003C\u002Fp\u003E\n\n\u003Cp style=\"text-align: justify;\"\u003EWe are researchers from the University of Tübingen (Germany) and Aix-Marseille Université (France). We are conducting a research study to examine how we form impressions of novel faces. Participation in this study will involve completing a survey. Your involvement will require about 20 minutes. You will receive £ 3.00 (~ $ US 3.66) for participating.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EThere are no known or anticipated risks to you for participating. Although this study will not benefit you personally, we hope that our results will add to the knowledge about psychology and evaluative learning in particular.\u003C\u002Fp\u003E\n\n\u003Cp style=\"text-align: justify;\"\u003EThe researcher will not know your name, and no identifying information will be connected to your survey answers in any way. The survey is therefore anonymous.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EYour responses will be numbered and stored on a password-protected computer hard drive. The information you provide will be kept until publication. A data file containing your anonymous responses (without your Prolific ID) will be stored in a secure online archive (i.e., the Open Science Framework). This data file will be available to other researchers without time limit. \u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EParticipation in this study is completely voluntary. You are free to decline to participate, to end participation at any time for any reason, or to refuse to answer any individual question without penalty or loss of compensation.\u003C\u002Fp\u003E\n \n\u003Cp style=\"text-align: justify;\"\u003EIf you want a copy of the consent form, click on the \"Download consent form\" button below (it will open a new tab in your browser; then go back to the experiment tab):\u003C\u002Fp\u003E\n\n\u003Ccenter\u003E\n\u003Cbutton type=\"submit\" onclick=\"window.open('${ 'static\u002Fconsent_form_copy_impression_of_novel_faces_prolific.pdf'}')\"\u003EDownload consent form\u003C\u002Fbutton\u003E\n\u003C\u002Fcenter\u003E\n\n\u003Cp style=\"text-align: justify;\"\u003EDo you understand this consent form, agree with it, and want to participate in the study?\u003C\u002Fp\u003E"
        },
        {
          "required": true,
          "type": "html",
          "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"consent_yes\" name=\"consent\" value=\"1\" onclick=\"document.getElementById('end').click()\" required\u003E\r\n  \u003Clabel for=\"consent_yes\"\u003EYes, I understand, I agree, and I want to participate\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"consent_no\" name=\"consent\" value=\"0\" onclick=\"document.getElementById('end').click()\"\u003E\r\n  \u003Clabel for=\"consent_no\"\u003ENo, I do not want to participate\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003ENext!\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Ccenter\u003E",
          "name": ""
        },
        {
          "required": true,
          "type": "html",
          "content": "\u003Cp style=\"text-align: justify;\"\u003E\u003Cb\u003EInvestigators:\u003C\u002Fb\u003E\u003C\u002Fp\u003E\r\n\r\n\u003Cp\u003EDr. Karoline Bading, University of Tübingen \r\n\u003Cbr\u003E\u003Ci\u003ESchleichstraße 4, 72076 Tübingen, Germany\u003C\u002Fi\u003E\r\n\u003Cbr\u003Ekaroline.bading@uni-tuebingen.de\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cp\u003EDr. Jérémy Béna, Aix-Marseille Université\r\n\u003Cbr\u003Ejeremy.bena@univ-amu.fr\u003C\u002Fp\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "UT_WBMW_Rot_RGB_01-1024x263(2).png": "embedded\u002F40cfda8ddbdc4b39a78eea411a6bf7e84968cddb1bade22d5504c74f58b41a7c.png"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
// retrieve prolific pic
if (typeof jatos !== "undefined") {
   this.data.prolific_pid = jatos.urlQueryParameters.PROLIFIC_PID;
}

this.parent.parameters.instructions_conditioning = this.random.choice(['val_task', 'age_task']);

this.parent.parameters.resp_pos_learning = this.random.choice(['neg_old_left', 'neg_old_right']);

this.parameters.n_learn = 1; //24*3=72 but 24 for test
this.parameters.n_mem = 1; //48 but 6 for test
this.parameters.n_ratings = 1; //48 but 6 for test

const male_face_cs = ["045_m_m_n_a","179_m_m_n_a","104_m_m_n_a","159_m_m_n_a","126_m_m_n_a","014_m_m_n_a","070_m_m_n_a","068_m_m_n_a","165_m_m_n_a","007_m_m_n_a","087_m_m_n_a","155_m_m_n_a","136_m_m_n_a","142_m_m_n_a","082_m_m_n_a","149_m_m_n_a","026_m_m_n_a","108_m_m_n_a","051_m_m_n_a","169_m_m_n_a","038_m_m_n_a","178_m_m_n_a","058_m_m_n_a","032_m_m_n_a"];

const female_face_cs = ["180_m_f_n_a","084_m_f_n_a","113_m_f_n_a","138_m_f_n_a","029_m_f_n_a","080_m_f_n_a","052_m_f_n_a","111_m_f_n_a","117_m_f_n_a","064_m_f_n_a","006_m_f_n_a","073_m_f_n_a","050_m_f_n_a","128_m_f_n_a","019_m_f_n_a","139_m_f_n_a","103_m_f_n_a","122_m_f_n_a","097_m_f_n_a","061_m_f_n_a","043_m_f_n_a","035_m_f_n_a","156_m_f_n_a","157_m_f_n_a"];

var male_cs = this.random.shuffle(male_face_cs);
var female_cs = this.random.shuffle(female_face_cs);

//Divide "male_cs" and "female_cs" into 8 3-item lists each and use the first 12 male and female cs to create the "cs_old" array. Use the last 12 items from "male_cs" and "female_cs" to create the "cs_new" array. Then concatenate "cs_old" and "cs_new" to create the "cs" array
//ensures that an equal number of random male and female cs are associated with US+ and US-
var male1 = male_cs.slice(0, 3); //first 3 items
var male2 = male_cs.slice(3, 6);  //3 following items
var male3 = male_cs.slice(6, 9); //3 following items
var male4 = male_cs.slice(9, 12); //3 following items
var male5 = male_cs.slice(12, 15); //3 following items
var male6 = male_cs.slice(15, 18);  //3 following items
var male7 = male_cs.slice(18, 21); //3 following items
var male8 = male_cs.slice(21, 24); //last 3 items

var female1 = female_cs.slice(0, 3); //first 3 items
var female2 = female_cs.slice(3, 6); //3 following items
var female3 = female_cs.slice(6, 9); //3 following items
var female4 = female_cs.slice(9, 12); //3 following items
var female5 = female_cs.slice(12, 15); //3 following items
var female6 = female_cs.slice(15, 18); //3 following items
var female7 = female_cs.slice(18, 21); //3 following items
var female8 = female_cs.slice(21, 24); //last 3 items

var cs_old = male1.concat(female1, male2, female2, male3, female3, male4, female4); //order important
var cs_new = male5.concat(female5, male6, female6, male7, female7, male8, female8); //order important

var cs = cs_old.concat(cs_new); //here is the cs list that will be used below

console.log("CS male", male_cs);
console.log("CS female", female_cs);

console.log("CS old", cs_old);
console.log("CS new", cs_new);

console.log("CS all", cs);

//4 conditions regarding US: Age (young or old) x Valence (positive or negative)
//24 US (two in each condition)
const pos_us_young = ['energetic','flexible','lively','open-minded','optimistic','strong'];

const pos_us_old = ['calm','dignified','nurturing','patient','realistic','wise'];
 
const neg_us_young = ['careless','impulsive','naive','selfish','spoilt','unrealistic'];

const neg_us_old = ['demented','feeble','frail','rigid','stubborn','weak'];

//shuffle these US lists
var us_young_pos = this.random.shuffle(pos_us_young);
var us_old_pos = this.random.shuffle(pos_us_old);

var us_young_neg = this.random.shuffle(neg_us_young);
var us_old_neg = this.random.shuffle(neg_us_old);

//concatenate us lists into positive us list and negative us list
var us_pos = us_young_pos.concat(us_old_pos); //order important
var us_neg = us_young_neg.concat(us_old_neg); //order important

var us_valences = ['positive','negative','dist'];
var na_vec = ['NA'];

var triallist = [];
var dists = [];

console.log("US+", us_pos);
console.log("US+y", us_young_pos);
console.log("US+o", us_old_pos);

console.log("US-", us_neg);
console.log("US-y",us_young_neg);
console.log("US-o",us_old_neg);

//positive YOUNG USs
for (var i=0 ; i < 6; i++) {
  triallist[i] = new Object();
// fixation cross trial?
  triallist[i].us_valence = us_valences[0];
  //cs and us
  triallist[i].cs = cs[i];
  triallist[i].us = us_young_pos[i];
  triallist[i].us_age = "young";

  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7,8,9,10,11]); //12 positions
  //first select targetpos
  triallist[i].idtarg = pos[0];
  // assign target and distracter images
  dists_young_pos = us_young_pos.slice(0, 6);
  console.log("dist+y", dists_young_pos);
  dists_young_pos.splice(i,1);
  console.log("dist+y", dists_young_pos);
  
  dists_old_pos = us_old_pos;
  console.log("dist+o", dists_old_pos);
  
  dists_young_neg = us_young_neg;
  console.log("dist-y", dists_young_neg);
  
  dists_old_neg = us_old_neg;
  console.log("dist+o", dists_old_neg);
  
  dists_pos_young = this.random.shuffle(dists_young_pos);
  console.log("dist+y", dists_pos_young);
  
  dists_pos_old = this.random.shuffle(dists_old_pos);
  console.log("dist+o", dists_pos_old);
  
  dists_neg_young = this.random.shuffle(dists_young_neg);
  console.log("dist-y", dists_neg_young);
  
  dists_neg_old = this.random.shuffle(dists_old_neg);
  console.log("dist-o",dists_neg_old);

  dists_pos_young = dists_pos_young.slice(0,2); //slice 2
  console.log("dist+y",dists_pos_young);

  dists_pos_old = dists_pos_old.slice(0,3); //slice 3
  console.log("dist+o",dists_pos_old);

  dists_neg_young = dists_neg_young.slice(0,3); //slice 3
  console.log("dist-y", dists_neg_young);

  dists_neg_old = dists_neg_old.slice(0,3); //slice 3
  console.log("dist-o", dists_neg_old);

  dists = dists_pos_young.concat(dists_pos_old, dists_neg_young, dists_neg_old);
  console.log("dists", dists);

  dists = this.random.shuffle(dists);
  console.log("dists",dists);

  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
  triallist[i].uss[pos[8]] = dists[7];
  triallist[i].uss[pos[9]] = dists[8];
  triallist[i].uss[pos[10]] = dists[9];
  triallist[i].uss[pos[11]] = dists[10];
};

//positive OLD USs
for (var i=6 ; i < 12; i++) {
  triallist[i] = new Object();
// fixation cross trial?
  triallist[i].us_valence = us_valences[0];
  //cs and us
  triallist[i].cs = cs[i];
  triallist[i].us = us_old_pos[i-6];
  triallist[i].us_age = "old";

  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7,8,9,10,11]); //12 positions
  //first select targetpos
  triallist[i].idtarg = pos[0];
  // assign target and distracter images
  dists_young_pos = us_young_pos;    
  dists_old_pos = us_old_pos.slice(0, 6);  
  dists_old_pos.splice(i-6,1);

  dists_young_neg = us_young_neg;  
  dists_old_neg = us_old_neg;
  
  dists_pos_young = this.random.shuffle(dists_young_pos);  
  dists_pos_old = this.random.shuffle(dists_old_pos);  
  dists_neg_young = this.random.shuffle(dists_young_neg);  
  dists_neg_old = this.random.shuffle(dists_old_neg);

  dists_pos_young = dists_pos_young.slice(0,3); //slice 3
  dists_pos_old = dists_pos_old.slice(0,2); //slice 2
  dists_neg_young = dists_neg_young.slice(0,3); //slice 3
  dists_neg_old = dists_neg_old.slice(0,3); //slice 3

  dists = dists_pos_young.concat(dists_pos_old, dists_neg_young, dists_neg_old);
  
  dists = this.random.shuffle(dists);

  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
  triallist[i].uss[pos[8]] = dists[7];
  triallist[i].uss[pos[9]] = dists[8];
  triallist[i].uss[pos[10]] = dists[9];
  triallist[i].uss[pos[11]] = dists[10];
};

//negative YOUNG USs
for (var i=12 ; i < 18; i++) {
  triallist[i] = new Object();
// fixation cross trial?
  triallist[i].us_valence = us_valences[1];
  //cs and us
  triallist[i].cs = cs[i];
  triallist[i].us = us_young_neg[i-12];
  triallist[i].us_age = "young";

  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7,8,9,10,11]); //12 positions
  //first select targetpos
  triallist[i].idtarg = pos[0];
  // assign target and distracter images
  dists_young_pos = us_young_pos;    
  dists_old_pos = us_old_pos;  
  
  dists_young_neg = us_young_neg.slice(0, 6);  
  dists_young_neg.splice(i-12,1);

  dists_old_neg = us_old_neg;
  
  dists_pos_young = this.random.shuffle(dists_young_pos);  
  dists_pos_old = this.random.shuffle(dists_old_pos);  
  dists_neg_young = this.random.shuffle(dists_young_neg);  
  dists_neg_old = this.random.shuffle(dists_old_neg);

  dists_pos_young = dists_pos_young.slice(0,3); //slice 3
  dists_pos_old = dists_pos_old.slice(0,3); //slice 3
  dists_neg_young = dists_neg_young.slice(0,2); //slice 2
  dists_neg_old = dists_neg_old.slice(0,3); //slice 3

  dists = dists_pos_young.concat(dists_pos_old, dists_neg_young, dists_neg_old);
  
  dists = this.random.shuffle(dists);

  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
  triallist[i].uss[pos[8]] = dists[7];
  triallist[i].uss[pos[9]] = dists[8];
  triallist[i].uss[pos[10]] = dists[9];
  triallist[i].uss[pos[11]] = dists[10];
};

//negative OLD USs
for (var i=18 ; i < 24; i++) {
  triallist[i] = new Object();
// fixation cross trial?
  triallist[i].us_valence = us_valences[1];
  //cs and us
  triallist[i].cs = cs[i];
  triallist[i].us = us_old_neg[i-18];
  triallist[i].us_age = "old";
 
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7,8,9,10,11]); //12 positions
  //first select targetpos
  triallist[i].idtarg = pos[0];
  // assign target and distracter images
  dists_young_pos = us_young_pos;    
  dists_old_pos = us_old_pos;  
  
  dists_young_neg = us_young_neg;  

  dists_old_neg = us_old_neg.slice(0, 6);
  dists_old_neg.splice(i-18,1);

  dists_pos_young = this.random.shuffle(dists_young_pos);  
  dists_pos_old = this.random.shuffle(dists_old_pos);  
  dists_neg_young = this.random.shuffle(dists_young_neg);  
  dists_neg_old = this.random.shuffle(dists_old_neg);

  dists_pos_young = dists_pos_young.slice(0,3); //slice 3
  dists_pos_old = dists_pos_old.slice(0,3); //slice 3
  dists_neg_young = dists_neg_young.slice(0,3); //slice 3
  dists_neg_old = dists_neg_old.slice(0,2); //slice 2

  dists = dists_pos_young.concat(dists_pos_old, dists_neg_young, dists_neg_old);
  
  dists = this.random.shuffle(dists);

  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = triallist[i].us;
  triallist[i].uss[pos[1]] = dists[0];
  triallist[i].uss[pos[2]] = dists[1];
  triallist[i].uss[pos[3]] = dists[2];
  triallist[i].uss[pos[4]] = dists[3];
  triallist[i].uss[pos[5]] = dists[4];
  triallist[i].uss[pos[6]] = dists[5];
  triallist[i].uss[pos[7]] = dists[6];
  triallist[i].uss[pos[8]] = dists[7];
  triallist[i].uss[pos[9]] = dists[8];
  triallist[i].uss[pos[10]] = dists[9];
  triallist[i].uss[pos[11]] = dists[10];
};

//new CSs
for (var i=24 ; i < 48; i++) {
  triallist[i] = new Object();
  // fixation cross trial?
  triallist[i].us_valence = us_valences[2];
  //cs and us (remove 'static/' to reduce data file size)
  triallist[i].cs = cs[i];
  triallist[i].us = na_vec[0];
  //idmem options: shuffle positions
  var pos = this.random.shuffle([0,1,2,3,4,5,6,7,8,9,10,11])
  // assign target and distracter images
  dists_young_pos = this.random.shuffle(us_young_pos);
  dists_old_pos = this.random.shuffle(us_old_pos);
  dists_young_neg = this.random.shuffle(us_young_neg);
  dists_old_neg = this.random.shuffle(us_old_neg);

  dists_pos_young = dists_young_pos.slice(0,3);
  dists_pos_old = dists_old_pos.slice(0,3);
  dists_neg_young = dists_young_neg.slice(0,3);
  dists_neg_old = dists_old_neg.slice(0,3);
  
  dists = dists_pos_young.concat(dists_pos_old, dists_neg_young, dists_neg_old);
  dists = this.random.shuffle(dists);
  
  triallist[i].uss = new Array;
  triallist[i].uss[pos[0]] = dists[0];
  triallist[i].uss[pos[1]] = dists[1];
  triallist[i].uss[pos[2]] = dists[2];
  triallist[i].uss[pos[3]] = dists[3];
  triallist[i].uss[pos[4]] = dists[4];
  triallist[i].uss[pos[5]] = dists[5];
  triallist[i].uss[pos[6]] = dists[6];
  triallist[i].uss[pos[7]] = dists[7];
  triallist[i].uss[pos[8]] = dists[8];
  triallist[i].uss[pos[9]] = dists[9];
  triallist[i].uss[pos[10]] = dists[10];
  triallist[i].uss[pos[11]] = dists[11];
};

triallist_learning = triallist.slice(0,24)

if(typeof(jatos) != 'undefined'){
 //jatos.studySessionData.triallist = triallist;
 jatos.studySessionData.triallist_learning = triallist_learning;
 jatos.studySessionData.triallist = triallist;
} else {  
  this.parent.parameters.triallist_learning = triallist_learning;
  this.parent.parameters.triallist = triallist;
}

console.log("trial list learning:", triallist_learning);
console.log("trial list:", triallist);
}
      },
      "title": "consent",
      "width": "m",
      "tardy": true
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 771.4,
          "height": 101.25,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "As you do not wish to participate in this study, please press the Esc key \nand return your submission on Prolific by selecting the 'Stop without completing' button.\n\nThank you for your comprehension.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "20",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "if_consent_no",
      "tardy": true,
      "skip": "${this.state.consent!=0}"
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "full_screen",
      "plugins": [
        {
          "type": "fullscreen",
          "message": "",
          "hint": "",
          "path": "lab.plugins.Fullscreen"
        }
      ],
      "content": [
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "if_consent_yes",
          "tardy": true,
          "skip": "${this.state.consent!= 1}",
          "content": [
            {
              "type": "lab.html.Page",
              "items": [
                {
                  "type": "text",
                  "title": "Before you start...",
                  "content": "\u003Cp\u003EBefore you start, please switch off phone\u002Fe-mail\u002Fmusic so you can focus on this study.\u003C\u002Fp\u003E\n\n\u003Cp\u003EAlso, make sure you are using a computer  to take part in this study.\u003C\u002Fp\u003E\n\n\u003Cp\u003EThank you!\u003C\u002Fp\u003E"
                },
                {
                  "required": true,
                  "type": "html",
                  "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n  \u003Cform\u003E\r\n\u003Cdiv id=\"weiterdiv\"\u003E\u003Cbutton id=\"end\"\u003EStart!\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fform\u003E\r\n\u003C\u002Fcenter\u003E",
                  "name": ""
                }
              ],
              "scrollTop": true,
              "submitButtonText": "Los geht's!",
              "submitButtonPosition": "hidden",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "before_you_start",
              "width": "m"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 782.68,
                  "height": 232.33,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Thank you very much for your participation!\n\nYour voluntary participation makes an important contribution to a developing\nbody of knowledge in psychological science.\n\nWithout volunteer participants like you, the research we are doing would not be possible \nand we want to thank you for this contribution.\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "welcome_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "welcome"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 622.55,
                  "height": 179.9,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The experiment consists of three parts and will take about 20 minutes.\n\nPlease read the following instructions attentively and perform all tasks \ncarefully and with due focus.\n\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "general_info_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "general_info"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 4143.07,
                  "height": 389.62,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "In the first part of the experiment you will be presented with \nface-trait adjective pairs.\n\nThe faces will always be presented in the middle of the screen. \nAfter a brief delay, the trait will appear underneath.\n\nEach face-trait pair will be presented for a limited time.\n\nYour task will be to form an impression of each face-trait pair.\n\nSpecifically, you will have to indicate whether you think each face-trait is \nrather ${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? \"negative\" : \"positive\") : (this.state.resp_pos_learning == 'neg_old_left' ? \"typical of old people\" : \"typical of young people\") } or rather ${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? \"positive\" : \"negative\") : (this.state.resp_pos_learning == 'neg_old_left' ? \"typical of young people\" : \"typical of old people\") }.\n\n\nPress the spacebar to continue with the instructions.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "learning_instructions_1"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 4561.09,
                  "height": 442.06,
                  "stroke": "",
                  "strokeWidth": 1,
                  "fill": "#000000",
                  "text": "Next, you will be presented with the face-trait pairs.\n\nAgain, your task is to form an impression of each face-trait pair.\n\nPlease indicate whether your think each pair is rather ${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? \"negative\" : \"positive\") : (this.state.resp_pos_learning == 'neg_old_left' ? \"typical of old people\" : \"typical of young people\") } or rather ${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? \"positive\" : \"negative\") : (this.state.resp_pos_learning == 'neg_old_left' ? \"typical of young people\" : \"typical of old people\") }.\n\nIf you think the pair is rather ${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? \"negative\" : \"positive\") : (this.state.resp_pos_learning == 'neg_old_left' ? \"typical of old people\" : \"typical of young people\") }, press Key A on your keyboard.\n\nIf you think the pair is rather ${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? \"positive\" : \"negative\") : (this.state.resp_pos_learning == 'neg_old_left' ? \"typical of young people\" : \"typical of old people\") }, press Key L on your keyboard. \n \nAlthough the presentation time is limited, please try your best to provide a response\non each face-trait pair.\n\nThis part of the experiment will take about 7 minutes.\n\n\nWhen you are ready, press the spacebar to start the task.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_instructions_2"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "learning_instructions_2"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw",
                "n": "72"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData.triallist_learning;
} else {
  this.options.templateParameters = this.parent.parameters.triallist_learning;
}
}
              },
              "title": "learning_loop",
              "tardy": true,
              "indexParameter": "count_trial_learning",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {
                  "run": function anonymous(
) {
//remove mouse
document.body.style.cursor = 'none' 
}
                },
                "title": "learning_sequence",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "image",
                        "left": 0,
                        "top": -90,
                        "angle": 0,
                        "width": 285,
                        "height": 360,
                        "stroke": null,
                        "strokeWidth": 0,
                        "fill": "black",
                        "src": "${ 'static\u002F' + this.parameters.cs + '.jpg' }",
                        "autoScale": undefined
                      },
                      {
                        "type": "i-text",
                        "left": -275,
                        "top": 225,
                        "angle": 0,
                        "width": 2332.91,
                        "height": 63.46,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'negative' : 'positive') : (this.state.resp_pos_learning == 'neg_old_left' ? 'typical old' : 'typical young') }\nkey A",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "26",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      },
                      {
                        "type": "i-text",
                        "left": 275,
                        "top": 225,
                        "angle": 0,
                        "width": 2332.91,
                        "height": 63.46,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'positive' : 'negative') : (this.state.resp_pos_learning == 'neg_old_left' ? 'typical young' : 'typical old') }\nkey L",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "26",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "learning_trial_cs_alone",
                    "timeout": "500"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "image",
                        "left": 0,
                        "top": -90,
                        "angle": 0,
                        "width": 285,
                        "height": 360,
                        "stroke": null,
                        "strokeWidth": 0,
                        "fill": "black",
                        "src": "${ 'static\u002F' + this.parameters.cs + '.jpg' }",
                        "autoScale": undefined
                      },
                      {
                        "type": "i-text",
                        "left": -275,
                        "top": 225,
                        "angle": 0,
                        "width": 2332.91,
                        "height": 63.46,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'negative' : 'positive') : (this.state.resp_pos_learning == 'neg_old_left' ? 'typical old' : 'typical young') }\nkey A",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "26",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      },
                      {
                        "type": "i-text",
                        "left": 275,
                        "top": 225,
                        "angle": 0,
                        "width": 2332.91,
                        "height": 63.46,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'positive' : 'negative') : (this.state.resp_pos_learning == 'neg_old_left' ? 'typical young' : 'typical old') }\nkey L",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "26",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      },
                      {
                        "type": "rect",
                        "left": 0,
                        "top": 111,
                        "angle": 0,
                        "width": 285,
                        "height": 50,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 111,
                        "angle": 0,
                        "width": 291.83,
                        "height": 33.9,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "#8dfc7a",
                        "text": "${ this.parameters.us}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "30",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress(a, A)": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'neg_resp' : 'pos_resp') : (this.state.resp_pos_learning == 'neg_old_left' ? 'old_resp' : 'young_resp') }",
                      "keypress(l, L)": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'pos_resp' : 'neg_resp') : (this.state.resp_pos_learning == 'neg_old_left' ? 'young_resp' : 'old_resp') }"
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "learning_trial_cs_us_response",
                    "timeout": "2200",
                    "timeline": [],
                    "tardy": true
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "image",
                        "left": 0,
                        "top": -90,
                        "angle": 0,
                        "width": 285,
                        "height": 360,
                        "stroke": null,
                        "strokeWidth": 0,
                        "fill": "black",
                        "src": "${ 'static\u002F' + this.parameters.cs + '.jpg' }",
                        "autoScale": undefined
                      },
                      {
                        "type": "i-text",
                        "left": -275,
                        "top": 225,
                        "angle": 0,
                        "width": 2332.91,
                        "height": 63.46,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'negative' : 'positive') : (this.state.resp_pos_learning == 'neg_old_left' ? 'typical old' : 'typical young') }\nkey A",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "26",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      },
                      {
                        "type": "i-text",
                        "left": 275,
                        "top": 225,
                        "angle": 0,
                        "width": 2332.91,
                        "height": 63.46,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.instructions_conditioning == 'val_task') ? (this.state.resp_pos_learning == 'neg_old_left' ? 'positive' : 'negative') : (this.state.resp_pos_learning == 'neg_old_left' ? 'typical young' : 'typical old') }\nkey L",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "26",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 175,
                        "angle": 0,
                        "width": 1028.36,
                        "height": 27.12,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ (this.state.ended_on == 'response') ? '_______________\\n_______________' : 'no response'}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "24",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      },
                      {
                        "type": "rect",
                        "left": 0,
                        "top": 111,
                        "angle": 0,
                        "width": 285,
                        "height": 50,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black"
                      },
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 111,
                        "angle": 0,
                        "width": 291.83,
                        "height": 33.9,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "#8dfc7a",
                        "text": "${ this.parameters.us}",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": "30",
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "learning_trial_cs_us_post_response",
                    "timeout": "${ 1000+2200-this.state.duration }",
                    "tardy": true
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_learning",
                    "timeout": "2000"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 536.25,
                  "height": 179.9,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The first part of the experiment is now finished!\n\nYou have now seen all face-trait pairs and may continue with\nthe second part of the experiment.\n\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "learning_end"
              },
              "parameters": {},
              "messageHandlers": {
                "commit": function anonymous(
) {
//show mouse again
document.body.style.cursor = 'default'
}
              },
              "title": "learning_end"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 708.19,
                  "height": 389.62,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "In the second part of the experiment, you will be presented with individual faces.\n\nSome of these faces were part of the previously presented face-trait pairs.\n\nOther faces will be new: they were not part of the face-trait pairs you saw in the\nprevious task.\n\nFor each face, please indicate whether it is\n\n\"old\" (i.e., part of the previously presented face-trait pairs) or\n\n\"new\" (i.e., NOT part of the previously presented face-trait pairs).\n\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "memory_instructions_1"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "memory_instructions_1"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 727.89,
                  "height": 310.98,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Whenever you classify a face as \"old\", you will be asked to perform a second task.\n\nIn this second task, you will be presented with eight trait adjectives. \nYour task will be to select the trait with which the face was previously paired with.\n\nIf you can remember the paired trait, click on it.\n\nIf you cannot remember the previously paired trait, try to guess the correct one. \nClick on the trait corresponding to your guess.\n\n\nWhen you are ready, press the spacebar to start the task.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "memory_instructions_2"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "memory_instructions_2"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw",
                "n": "48"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData.triallist;
} else {
  this.options.templateParameters = this.parent.parameters.triallist;
}
}
              },
              "title": "memory_loop",
              "tardy": true,
              "indexParameter": "count_trial_memory",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "memory_sequence",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_memory_1",
                    "timeout": "500"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.cs + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"task\" id=\"recognition_memory\"\u003E\u003C\u002Fdiv\u003E\r\n\r\n\u003Cform\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n    \u003Cdiv class=\"mem\"\u003E\r\n        \u003Cinput type=\"radio\" id=\"old\" name=\"reco_resp\" value=\"old\" required onclick=\"document.getElementById('reco').click();\"\u003E\r\n        \u003Clabel for =\"old\"\u003EYes (old)\u003C\u002Flabel\u003E      \r\n\r\n        \u003Cinput type=\"radio\" id=\"new\" name=\"reco_resp\" value=\"new\" onclick=\"document.getElementById('reco').click();\"\u003E\r\n        \u003Clabel for =\"new\"\u003ENo (new) \u003C\u002Flabel\u003E      \r\n    \u003C\u002Fdiv\u003E\r\n \u003C\u002Fdiv\u003E\r\n \u003C\u002Fcenter\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"reco\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\r\n\u003C\u002Fform\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
debugger
}
                    },
                    "title": "recognition_trial"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_memory_2",
                    "timeout": "500",
                    "tardy": true,
                    "skip": "${this.state.reco_resp!=\"old\"}"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.cs + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E\r\n",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"task\" id=\"source_memory\"\u003E\u003C\u002Fdiv\u003E\r\n\r\n\u003Cform\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n    \u003Cdiv class=\"mem\"\u003E\r\n        \u003Cinput type=\"radio\" id=\"id1\" name=\"source_mem\" value=\"us1\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id1\"\u003E${ this.parameters.uss[0] }\u003C\u002Flabel\u003E   \r\n\r\n        \u003Cinput type=\"radio\" id=\"id2\" name=\"source_mem\" value=\"us2\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id2\"\u003E${ this.parameters.uss[1] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id3\" name=\"source_mem\" value=\"us3\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id3\"\u003E${ this.parameters.uss[2] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id4\" name=\"source_mem\" value=\"us4\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id4\"\u003E${ this.parameters.uss[3] }\u003C\u002Flabel\u003E \r\n        \r\n         \u003Cinput type=\"radio\" id=\"id5\" name=\"source_mem\" value=\"us5\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id5\"\u003E${ this.parameters.uss[4] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id6\" name=\"source_mem\" value=\"us6\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id6\"\u003E${ this.parameters.uss[5] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cbr\u003E\r\n        \r\n        \u003Cinput type=\"radio\" id=\"id7\" name=\"source_mem\" value=\"us7\" required onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id7\"\u003E${ this.parameters.uss[6] }\u003C\u002Flabel\u003E    \r\n\r\n        \u003Cinput type=\"radio\" id=\"id8\" name=\"source_mem\" value=\"us8\" onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id8\"\u003E${ this.parameters.uss[7] }\u003C\u002Flabel\u003E\r\n\r\n        \u003Cinput type=\"radio\" id=\"id9\" name=\"source_mem\" value=\"us9\" onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id9\"\u003E${ this.parameters.uss[8] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id10\" name=\"source_mem\" value=\"us10\" onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id10\"\u003E${ this.parameters.uss[9] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id11\" name=\"source_mem\" value=\"us11\" onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id11\"\u003E${ this.parameters.uss[10] }\u003C\u002Flabel\u003E \r\n\r\n        \u003Cinput type=\"radio\" id=\"id12\" name=\"source_mem\" value=\"us12\" onclick=\"document.getElementById('source').click()\"\u003E\r\n        \u003Clabel for =\"id12\"\u003E${ this.parameters.uss[11] }\u003C\u002Flabel\u003E \r\n\r\n    \u003C\u002Fdiv\u003E\r\n \u003C\u002Fdiv\u003E\r\n\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"source\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\r\n \u003C\u002Fcenter\u003E\r\n\u003C\u002Fform\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "source_trial",
                    "tardy": true,
                    "skip": "${this.state.reco_resp!=\"old\"}"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 446.92,
                  "height": 75.03,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The second part of the experiment is now finished.\n\nPress the spacebar to continue with the third part.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "memory_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "memory_end"
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 774.87,
                  "height": 284.76,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "In the third part of the experiment, you will again be presented with the faces.\n\nThis time, you will be asked to express your personal evaluation of the presented faces.\n\nTo do so, you will be presented with an 8-point scale\nranging from very negative (left) to very positive (right).\n\nPlease click on the scale point that best represents your evaluation of a given face.\n\n\nWhen you are ready, press the spacebar to start the task.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "ratings_instructions"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "rating_instructions"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [],
              "sample": {
                "mode": "draw",
                "n": "48"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {
                "before:prepare": function anonymous(
) {
if(typeof(jatos) != 'undefined'){
  this.options.templateParameters = jatos.studySessionData.triallist;
} else {
  this.options.templateParameters = this.parent.parameters.triallist;
}
}
              },
              "title": "rating_loop",
              "tardy": true,
              "indexParameter": "count_trial_ratings",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "sequence_rating",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cstyle\u003E\r\n      form .statement {\r\n        display:block;\r\n        font-weight: bold;\r\n        padding: 30px 0 0 4.25%;\r\n        margin-bottom:10px;\r\n        }\r\n      form .likert {\r\n        list-style:none;\r\n        width:100%;\r\n        margin:0;\r\n        padding:0 0 0;\r\n        display:block;\r\n        }\r\n\r\n      form .likert li {\r\n        display:inline-block;\r\n        width:8%;\r\n        text-align:center;\r\n        vertical-align: top;\r\n        }\r\n\r\n      form .likert li input[type=radio] {\r\n        width: 20px;\r\n        height: 20px;\r\n        display:block;\r\n        position:relative;\r\n        top:0;\r\n        left:50%;\r\n        margin-left:-4px;\r\n        }\r\n\u003C\u002Fstyle\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"cat\"\u003E\r\n    \u003Cimg src=\"${ 'static\u002F' + this.parameters.cs + '.jpg' }\"\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Ccenter\u003E\r\n  \u003Cdiv class=\"task\" id=\"ratings\"\u003E\u003C\u002Fdiv\u003E\r\n  \u003Cul class='likert'\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"1\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 1\u003Cbr\u003Every negative\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"2\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 2\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"3\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 3\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"4\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 4\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"5\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 5\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"6\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 6\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"7\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 7\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n    \u003Cli\u003E\r\n      \u003Cinput type=\"radio\" name=\"cs_rating\" value=\"8\" onclick=\"document.getElementById('source').click()\"\u003E\r\n      \u003Clabel\u003E 8\u003Cbr\u003Every positive\u003C\u002Flabel\u003E\r\n    \u003C\u002Fli\u003E\r\n  \u003C\u002Ful\u003E\r\n\r\n    \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"source\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fcenter\u003E\r\n",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
debugger
}
                    },
                    "title": "rating_trial"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "blank_rating",
                    "timeout": "500"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 710.03,
                  "height": 153.68,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "The third and final part of the experiment is now finished.\n\nNow we have a few short questions about your experience performing the study.\n\n\nPress the spacebar to continue.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": "20",
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": "ratings_end"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "rating_end"
            },
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "check_socio_demo": "1"
                }
              ],
              "sample": {
                "mode": "draw-shuffle"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "check_loop",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {
                  "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                },
                "title": "sequence_check",
                "content": [
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "",
                        "content": "Wie alt bist Du (in Jahren)?"
                      },
                      {
                        "required": true,
                        "type": "textarea",
                        "name": "age"
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "age",
                    "skip": true
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Welchem Geschlecht fühlst Du Dich zugehörig?",
                        "content": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"male\" name=\"gender\" value=\"0\" required onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"male\"\u003Emännlich\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"female\" name=\"gender\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"female\"\u003Eweiblich\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"diverse\" name=\"gender\" value=\"2\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"diverse\"\u003Edivers\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"kA\" name=\"gender\" value=\"3\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"kA\"\u003Ekeine Angabe\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "gender",
                    "skip": true
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Did you pay attention to the trait adjectives and faces presented throughout the entire study?",
                        "content": "(the response to this question will not affect your payment)"
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"yes\" name=\"pay_attention\" value=\"1\" required onclick=\"document.getElementById('end').click()\"\u003E\r\n  \u003Clabel for=\"yes\"\u003EYes\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"no\" name=\"pay_attention\" value=\"0\" onclick=\"document.getElementById('end').click()\"\u003E\r\n  \u003Clabel for=\"no\"\u003ENo\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "pay_attention"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "It would be very helpful if you could tell us at this point whether you have taken the requested responses seriously, so that we can use your answers for our scientific analysis, or whether you were just clicking through to take a look at the survey?",
                        "content": "(again, this will not affect your payment)\n"
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"serious\" name=\"serious\" value=\"1\" required onclick=\"document.getElementById('end').click()\"\u003E\r\n  \u003Clabel for=\"serious\"\u003EI have taken the requested responses seriously\r\n\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n  \u003Cinput type=\"radio\" id=\"not_serious\" name=\"serious\" value=\"0\" onclick=\"document.getElementById('end').click()\"\u003E\r\n  \u003Clabel for=\"not_serious\"\u003EI have just clicked through, please discard my data\r\n\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EContinue\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003C\u002Fcenter\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "hidden",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "seriousness"
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Vielen Dank für die Teilnahme an unserer Studie! ",
                        "content": ""
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\r\n\u003Cdiv style=\"font-size: 1.2vw\"\u003E  \r\n\u003Cp style=\"text-align: justify;\"\u003EMit der Studie wollten wir untersuchen, ob Deine Einstellung zu den Gesichtern durch die Valenz der gepaarten Szenerie (positiv vs. negativ) beeinflusst wird. Außerdem wollten wir wissen, ob deine Einstellung zu den Gesichtern davon abhängt, ob Du Dich an die gepaarte Szenerie erinnern kannst.\r\n\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EFalls Du noch Fragen zur Studie hast, kannst Du Dich gerne an karoline.bading@uni-jena.de wenden.\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EWenn Du an der FSU Jena Psychologie studierst und für die Teilnahme mit 0.5 VP-Stunden vergütet werden möchtest, kannst Du im nächsten Schritt einen Absolvierungscode für die Verbuchung im VPHS generieren. ACHTUNG: Die Absolvierungscodes werden erst nach Abschluss der Datenerhebung (Ende Februar 2023) im VPHS freigeschaltet. Eine Verbuchung Deiner 0.5 VP-Stunden wird also erst ab Anfang März 2023 möglich sein.\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EHast Du noch irgendwelche Fragen oder Anmerkungen, die Du uns mitteilen möchtest? Dann trage sie gerne in das folgende Textfeld ein.\u003C\u002Fp\u003E\r\n\r\n \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fmain\u003E",
                        "name": ""
                      },
                      {
                        "required": false,
                        "type": "input",
                        "name": "comment_study"
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "debriefing_and_comment",
                    "skip": true
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Möchtest Du einen Absolvierungscode generieren?",
                        "content": "Mit diesem kannst Du dann Deine Teilnahme auf dem Versuchspersonenstundenserver VPHS verbuchen.\nFür die Teilnahme erhältst Du 0.5 VP-Stunden."
                      },
                      {
                        "required": true,
                        "type": "html",
                        "content": "\u003Cbr\u003E\r\n\u003Ccenter\u003E\r\n\u003Cdiv class=\"radio-toolbar\"\u003E\r\n  \u003Cinput type=\"radio\" id=\"VP_yes\" name=\"vp_code\" value=\"1\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\" required\u003E\r\n  \u003Clabel for=\"VP_yes\"\u003EJa, möchte ich.\u003C\u002Flabel\u003E\u003Cbr\u003E\u003Cbr\u003E\r\n\r\n  \u003Cinput type=\"radio\" id=\"VP_no\" name=\"vp_code\" value=\"0\" onclick=\"document.getElementById('weiterdiv').style.visibility='visible';\"\u003E\r\n  \u003Clabel for=\"VP_no\"\u003ENein, möchte ich nicht.\u003C\u002Flabel\u003E\u003Cbr\u003E\r\n  \u003Cdiv id=\"weiterdiv\" style=\"visibility:hidden;\"\u003E\u003Cbutton id=\"end\"\u003EWeiter\u003C\u002Fbutton\u003E\u003C\u002Fdiv\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Ccenter\u003E\r\n\r\n\u003C\u002Fform\u003E",
                        "name": ""
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "Continue →",
                    "submitButtonPosition": "hidden",
                    "files": {
                      "Bandeau+new+logo+2019.jpg": "embedded\u002F5ffb7db9f15ad3b748ba63804367e87b2d52bf35af7d1cc696d84ef88aad1724.jpg",
                      "Bildmarke_black_8cm.jpg": "embedded\u002F8d8205d13605ad5501ddcda7ec381eee3d98b9baf404875950775025a8c6f1bc.jpg"
                    },
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "VP_Stunde",
                    "width": "l",
                    "skip": true
                  },
                  {
                    "type": "lab.html.Page",
                    "items": [
                      {
                        "type": "text",
                        "title": "Als Nächstes musst Du Deinen persönlichen Absolvierungscode erstellen und in das Textfeld eintragen.",
                        "content": "Der Absolvierungscode setzt sich aus drei Komponenten zusammen.\n\n\n\n\n"
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Die erste Komponente lautet: 181_"
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Die zweite Komponente sind die ersten drei Buchstaben Deines Geburtsorts (in Großbuchstaben)."
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Die dritte Komponente sind die letzten drei Ziffern Deiner Handynummer."
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "BEISPIEL: Für eine Person mit Geburtsort Hamburg und Handynummer 0163-78965498 lautet der Code: 181_HAM498"
                      },
                      {
                        "required": true,
                        "type": "text",
                        "content": "Erstelle nun bitte Deinen persönlichen Code (basierend auf obigen Regeln), notiere ihn Dir für die Verbuchung im VPHS (ab Februar 2023) und trage ihn dann in das folgende Textfeld ein."
                      },
                      {
                        "required": true,
                        "type": "textarea",
                        "name": "code"
                      }
                    ],
                    "scrollTop": true,
                    "submitButtonText": "\u003Cspan\u003EWeiter\u003C\u002Fspan\u003E\u003C\u002Fdiv\u003E",
                    "submitButtonPosition": "right",
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {
                      "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
                    },
                    "title": "generate_code",
                    "tardy": true,
                    "skip": true
                  }
                ]
              }
            },
            {
              "type": "lab.html.Page",
              "items": [
                {
                  "type": "text",
                  "title": "If you have any comments feel free to include them below:"
                },
                {
                  "required": false,
                  "type": "textarea",
                  "name": "comment_study"
                }
              ],
              "scrollTop": true,
              "submitButtonText": "Continue →",
              "submitButtonPosition": "right",
              "files": {},
              "responses": {
                "": "comment"
              },
              "parameters": {},
              "messageHandlers": {
                "run": function anonymous(
) {
document.body.style.cursor = 'default'
}
              },
              "title": "comment"
            },
            {
              "type": "lab.html.Screen",
              "files": {},
              "responses": {
                "keypress(Space)": "end_study"
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "end_study_redirect",
              "content": " \u003Cmain class=\"content-vertical-center\r\n             content-horizontal-center\"\u003E\r\n \u003Cdiv style=\"font-size: 1.2vw; width: 70%;\"\u003E  \r\n\u003Cp style=\"text-align: justify;\"\u003EThe experiment is now over. Thank you very much for your participation!\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EIn this experiment, we want to see whether the valence of the trait adjectives paired with faces (positive vs. negative) has an influence on your evaluation of the faces. In addition, we were also interested in your memory for the face-trait pairs.\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EIn the study phase in which you saw the face-trait pairs, some participants are instructed to pay attention to valence (whether the pair is rather positive or negative); other participants are instructed to pay attention to age (whether the pair is rather typical of old or young people). We want to test whether the influence of the trait adjectives on evaluations of the faces and on memory depends on the task participants performed when exposed to the face-trait pairs.\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003EIf you have any question or comment, or if you would like to receive additional information on the present study, please do not hesitate to contact the person in charge of this research at the following e-mail address: karoline.bading@uni-tuebingen.de\u003C\u002Fp\u003E\r\n\r\n\u003Cp style=\"text-align: justify;\"\u003E\u003Cb\u003EPress the spacebar to be redirected to Prolific.\u003C\u002Fb\u003E\u003C\u002Fp\u003E\r\n\r\n \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fmain\u003E"
            }
          ]
        }
      ]
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())